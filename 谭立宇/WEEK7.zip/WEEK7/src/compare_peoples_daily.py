"""
汇总人民日报 NER 各方案的评估结果，打印对比表

使用方式：
  python compare_peoples_daily.py

前提：
  - 已运行 evaluate_peoples_daily.py 和 evaluate_peoples_daily.py --use_crf
"""

import json
from pathlib import Path

ROOT = Path(__file__).parent.parent
LOG_DIR = ROOT / "outputs" / "logs"


def load_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    linear_res = load_json(LOG_DIR / "eval_peoples_daily_linear_validation.json")
    crf_res = load_json(LOG_DIR / "eval_peoples_daily_crf_validation.json")

    print("\n" + "=" * 80)
    print("人民日报 NER — BERT 方案汇总对比")
    print("=" * 80)

    header = f"{'方案':<25} {'Precision':>10} {'Recall':>10} {'F1':>10} {'非法序列':>10}"
    print(header)
    print("-" * 67)

    if linear_res:
        ill = linear_res["illegal_stats"]["total_illegal"]
        print(
            f"{'BERT + Linear':<25} "
            f"{linear_res['precision']:>10.4f} "
            f"{linear_res['recall']:>10.4f} "
            f"{linear_res['f1']:>10.4f} "
            f"{ill:>10d}"
        )
    else:
        print(f"{'BERT + Linear':<25} {'（未找到结果，请运行 evaluate_peoples_daily.py）':>50}")

    if crf_res:
        ill = crf_res["illegal_stats"]["total_illegal"]
        print(
            f"{'BERT + CRF':<25} "
            f"{crf_res['precision']:>10.4f} "
            f"{crf_res['recall']:>10.4f} "
            f"{crf_res['f1']:>10.4f} "
            f"{ill:>10d}"
        )
    else:
        print(f"{'BERT + CRF':<25} {'（未找到结果，请运行 evaluate_peoples_daily.py --use_crf）':>50}")

    print("\n" + "=" * 80)
    print("关键结论：")
    if linear_res and crf_res:
        f1_diff = crf_res["f1"] - linear_res["f1"]
        ill_linear = linear_res["illegal_stats"]["total_illegal"]
        print(f"  1. CRF vs Linear：F1 {'↑' if f1_diff >= 0 else '↓'}{abs(f1_diff):.4f}")
        print(f"  2. 线性头非法序列：{ill_linear} 条；CRF 非法序列：0 条")
        print(f"     → CRF 通过 Viterbi 解码在数学上保证序列合法性")
    print("=" * 80)


if __name__ == "__main__":
    main()
