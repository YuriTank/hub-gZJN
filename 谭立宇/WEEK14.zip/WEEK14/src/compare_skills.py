"""
对比 V1 vs V2 shipping_logistics skill 的评估脚本。
评估 8 道 logistics 题目，记录准确率和 token 消耗。
"""
import os, sys, json, re
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "src"))

from openai import OpenAI
from evaluator import Evaluator

client = OpenAI(
    api_key=os.getenv("DEEPSEEK_API_KEY"),
    base_url="https://api.deepseek.com",
)

EVAL_SET = ROOT / "data" / "eval_set.json"
ev = Evaluator(str(EVAL_SET))

# 取 logistics 类别的题目
logistics_qs = {qid: q for qid, q in ev.questions.items() if q["category"] == "logistics"}


def build_system_prompt(skill_content: str) -> str:
    return f"""你是云购商城的智能客服助手。

你的所有知识来源于以下技能文档，严格基于文档内容回答，不要自行推断或编造政策。

## 回答规则（严格遵守）
- 【能回答】如果技能文档覆盖了用户问题：直接给出完整具体的答案（含具体天数/金额/工作日数等政策细节）。**不要在答案中加"建议联系人工客服"之类的推脱话**。
- 【不能回答】如果技能文档确实不覆盖：**仅回答一句** "需要联系人工客服"，不要编造答案，也不要列举可能的情况。

## 当前知识库

### 技能：shipping_logistics
{skill_content}
"""


def run_eval(skill_content: str, label: str) -> dict:
    system_prompt = build_system_prompt(skill_content)
    results = []
    total_tokens = {"prompt": 0, "completion": 0}

    for qid, q in sorted(logistics_qs.items()):
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": q["question"]},
            ],
            temperature=0,
            max_tokens=400,
        )
        answer = response.choices[0].message.content.strip()
        usage = response.usage
        total_tokens["prompt"] += usage.prompt_tokens
        total_tokens["completion"] += usage.completion_tokens

        ok, reason = ev.evaluate_answer(answer, qid)
        mark = "✓" if ok else "✗"
        print(f"  Q{qid:02d} {mark} {q['question'][:45]:<45} → {answer[:60]}")
        if not ok:
            print(f"        fail: {reason}")

        results.append({
            "id": qid, "question": q["question"],
            "answer": answer, "correct": ok, "reason": reason,
            "prompt_tokens": usage.prompt_tokens,
            "completion_tokens": usage.completion_tokens,
        })

    correct = sum(1 for r in results if r["correct"])
    total = len(results)

    skill_chars = len(skill_content)
    skill_tokens_approx = int(skill_chars / 1.5)

    summary = {
        "label": label,
        "timestamp": datetime.now().isoformat(),
        "accuracy": round(correct / total, 3),
        "correct": correct,
        "total": total,
        "skill_chars": skill_chars,
        "skill_tokens_approx": skill_tokens_approx,
        "actual_prompt_tokens_total": total_tokens["prompt"],
        "actual_completion_tokens_total": total_tokens["completion"],
        "avg_prompt_tokens_per_q": round(total_tokens["prompt"] / total, 1),
        "avg_completion_tokens_per_q": round(total_tokens["completion"] / total, 1),
        "results": results,
    }
    return summary


if __name__ == "__main__":
    skill_dir = ROOT / "skills" / "shipping_logistics"

    # V1
    v1_content = (skill_dir / "SKILL_V1.md").read_text(encoding="utf-8")
    print("=" * 60)
    print("  V1 (verbose) 评估 — 8 道 logistics 题")
    print("=" * 60)
    v1_result = run_eval(v1_content, "V1 verbose")
    print(f"\nV1 结果: {v1_result['correct']}/{v1_result['total']} = {v1_result['accuracy']:.1%}")
    print(f"Skill 字符数: {v1_result['skill_chars']}, 估算token: ~{v1_result['skill_tokens_approx']}")
    print(f"实际 prompt tokens (8题合计): {v1_result['actual_prompt_tokens_total']}")
    print(f"平均每题 prompt tokens: {v1_result['avg_prompt_tokens_per_q']}")

    # V2
    v2_content = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
    print(f"\n{'=' * 60}")
    print("  V2 (optimized) 评估 — 8 道 logistics 题")
    print("=" * 60)
    v2_result = run_eval(v2_content, "V2 optimized")
    print(f"\nV2 结果: {v2_result['correct']}/{v2_result['total']} = {v2_result['accuracy']:.1%}")
    print(f"Skill 字符数: {v2_result['skill_chars']}, 估算token: ~{v2_result['skill_tokens_approx']}")
    print(f"实际 prompt tokens (8题合计): {v2_result['actual_prompt_tokens_total']}")
    print(f"平均每题 prompt tokens: {v2_result['avg_prompt_tokens_per_q']}")

    # 对比
    print(f"\n{'=' * 60}")
    print("  V1 vs V2 对比")
    print("=" * 60)
    print(f"  {'指标':<25} {'V1':>12} {'V2':>12} {'变化':>10}")
    print(f"  {'-'*25} {'-'*12} {'-'*12} {'-'*10}")
    print(f"  {'准确率':<23} {v1_result['accuracy']:>11.1%} {v2_result['accuracy']:>11.1%} {(v2_result['accuracy']-v1_result['accuracy']):>+9.1%}")
    print(f"  {'Skill 字符数':<21} {v1_result['skill_chars']:>12} {v2_result['skill_chars']:>12} {(1-v2_result['skill_chars']/v1_result['skill_chars'])*100:>+9.1f}%")
    print(f"  {'Skill 估算token':<18} {v1_result['skill_tokens_approx']:>12} {v2_result['skill_tokens_approx']:>12} {(1-v2_result['skill_tokens_approx']/v1_result['skill_tokens_approx'])*100:>+9.1f}%")
    print(f"  {'Prompt tokens/题':<17} {v1_result['avg_prompt_tokens_per_q']:>12} {v2_result['avg_prompt_tokens_per_q']:>12} {(1-v2_result['avg_prompt_tokens_per_q']/v1_result['avg_prompt_tokens_per_q'])*100:>+9.1f}%")

    out = ROOT / "outputs" / "skill_optimization_compare.json"
    out.write_text(json.dumps({"v1": v1_result, "v2": v2_result}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n✓ 对比结果已保存: {out}")
