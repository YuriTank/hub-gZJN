from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class SkillMetadata:
    name: str
    description: str
    version: str
    directory: Path
    trigger_hints: list[str] = field(default_factory=list)


@dataclass
class Skill:
    metadata: SkillMetadata
    content: Optional[str] = None
    is_loaded: bool = False


@dataclass
class Invocation:
    skill_name: str
    args: dict[str, str]


@dataclass
class ExecutionResult:
    success: bool
    stdout: str
    stderr: str
    returncode: int


SKILL_MD = "SKILL.md"
INVOCATION_RE = r"\{\{skill:([\w-]+)\s*([^}]*)\}\}"
