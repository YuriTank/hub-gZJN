import subprocess
import shlex
from pathlib import Path

from .models import Skill, ExecutionResult

EXEC_TIMEOUT = 60


def execute(skill: Skill, command: str, timeout: int = EXEC_TIMEOUT) -> ExecutionResult:
    cwd = skill.metadata.directory
    resolved = command
    if "{baseDir}" in resolved:
        resolved = resolved.replace("{baseDir}", str(cwd))
    try:
        result = subprocess.run(
            resolved,
            shell=True,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=timeout,
        )
        return ExecutionResult(
            success=result.returncode == 0,
            stdout=result.stdout.strip(),
            stderr=result.stderr.strip(),
            returncode=result.returncode,
        )
    except subprocess.TimeoutExpired:
        return ExecutionResult(
            success=False,
            stdout="",
            stderr=f"Command timed out after {timeout}s",
            returncode=-1,
        )
    except Exception as e:
        return ExecutionResult(
            success=False,
            stdout="",
            stderr=str(e),
            returncode=-1,
        )
