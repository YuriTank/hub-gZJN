from pathlib import Path
import yaml

from .models import SkillMetadata, SKILL_MD


def _find_skills_dirs() -> list[Path]:
    self_path = Path(__file__).resolve().parent.parent.parent
    candidates = [
        self_path / "skills",
        self_path.parent / "skills",
    ]
    return [d for d in candidates if d.is_dir()]


def _parse_frontmatter(text: str) -> tuple[dict | None, str]:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return None, text
    end = -1
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            end = i
            break
    if end == -1:
        return None, text
    front = "\n".join(lines[1:end])
    body = "\n".join(lines[end + 1:])
    try:
        meta = yaml.safe_load(front)
    except Exception:
        meta = None
    return meta, body


def scan_skills() -> list[SkillMetadata]:
    skills: list[SkillMetadata] = []
    for skills_dir in _find_skills_dirs():
        for entry in sorted(skills_dir.iterdir()):
            skill_md = entry / SKILL_MD
            if not skill_md.is_file():
                continue
            text = skill_md.read_text(encoding="utf-8", errors="replace")
            meta, _ = _parse_frontmatter(text)
            if meta is None or not isinstance(meta, dict):
                continue
            name = meta.get("name", entry.name)
            desc = meta.get("description", "")
            version = str(meta.get("version", "1.0.0"))
            skills.append(SkillMetadata(
                name=name,
                description=desc.strip(),
                version=version,
                directory=entry,
            ))
    return skills
