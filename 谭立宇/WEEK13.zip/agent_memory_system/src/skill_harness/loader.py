from pathlib import Path

from .models import Skill, SkillMetadata, SKILL_MD


def load_skill(metadata: SkillMetadata) -> Skill:
    path = metadata.directory / SKILL_MD
    if not path.exists():
        return Skill(metadata=metadata, content=None, is_loaded=False)
    content = path.read_text(encoding="utf-8", errors="replace")
    return Skill(metadata=metadata, content=content, is_loaded=True)


def unload_skill(skill: Skill) -> Skill:
    skill.content = None
    skill.is_loaded = False
    return skill
