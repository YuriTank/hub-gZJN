import re
from pathlib import Path
from typing import Optional

from .models import SkillMetadata, Skill, Invocation, ExecutionResult, SKILL_MD, INVOCATION_RE
from .scanner import scan_skills
from .loader import load_skill, unload_skill
from .executor import execute, EXEC_TIMEOUT


class SkillHarness:
    def __init__(self, skills_dir: Optional[Path] = None):
        self._skills_dir = skills_dir
        self._index: dict[str, SkillMetadata] = {}
        self._cache: dict[str, Skill] = {}
        self._scan()

    def _scan(self):
        metas = scan_skills()
        self._index = {m.name: m for m in metas}

    @property
    def available_skills(self) -> list[SkillMetadata]:
        return list(self._index.values())

    def get_skill_descriptions(self) -> str:
        if not self._index:
            return "（暂无可用技能）"
        lines = []
        for meta in self.available_skills:
            lines.append(f"- {meta.name}：{meta.description}")
        return "\n".join(lines)

    def get_skill(self, name: str) -> Optional[SkillMetadata]:
        return self._index.get(name)

    def load(self, name: str) -> Optional[Skill]:
        meta = self.get_skill(name)
        if meta is None:
            return None
        if name not in self._cache or not self._cache[name].is_loaded:
            self._cache[name] = load_skill(meta)
        return self._cache[name]

    def unload(self, name: str):
        if name in self._cache:
            self._cache[name] = unload_skill(self._cache[name])

    def execute(self, name: str, command: str, timeout: int = EXEC_TIMEOUT) -> Optional[ExecutionResult]:
        skill = self.load(name)
        if skill is None:
            return None
        return execute(skill, command, timeout=timeout)

    def parse_invocation(self, text: str) -> Optional[Invocation]:
        m = re.search(INVOCATION_RE, text)
        if not m:
            return None
        skill_name = m.group(1)
        raw_args = m.group(2).strip()
        args: dict[str, str] = {}
        for pair in re.findall(r'(\w+)=["\']?([^"\'\s}]+)["\']?', raw_args):
            args[pair[0]] = pair[1]
        return Invocation(skill_name=skill_name, args=args)

    def strip_invocation(self, text: str) -> str:
        return re.sub(INVOCATION_RE, "", text).strip()

    def refresh(self):
        self._cache.clear()
        self._scan()
