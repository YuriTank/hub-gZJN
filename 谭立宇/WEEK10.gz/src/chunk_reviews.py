"""
评论分块脚本：对解析后的热成像评论做分块处理

评论数据的特点决定了分块策略与年报不同：
  - 每条评论本身就是一个完整的语义单元
  - 核心策略 "per_review"：一条评论 = 一个 chunk，保留所有业务元信息
  - 可选策略 "fixed" 用于消融对比（但会切断评论，不推荐）

输出格式与 chunk_documents.py 兼容，确保 build_index.py 可直接使用。

每个 chunk 的 metadata 包含丰富的过滤字段：
  - brand / product_type / form_factor / model → 产品维度过滤
  - site / country → 地域维度过滤
  - rating → 评分过滤
  - date → 时间过滤
"""

import json
import logging
from pathlib import Path
from typing import Iterator

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

PARSED_DIR = Path(__file__).parent.parent / "data" / "parsed"
CHUNKS_DIR = Path(__file__).parent.parent / "data" / "chunks"
CHUNKS_DIR.mkdir(parents=True, exist_ok=True)


# ── 策略：逐条评论分块 ────────────────────────────────────────────────────────

def chunk_per_review(blocks: list[dict]) -> Iterator[dict]:
    """
    每条评论 = 一个 chunk。
    评论本身就是天然语义单位，不适合再切割。
    """
    for block in blocks:
        meta = block
        yield {
            "content": block["content"],
            "metadata": {
                # 通用元信息
                "section":     " > ".join(block["section_path"]) if block["section_path"] else "",
                "block_types": [block["block_type"]],
                "is_ocr":      block.get("is_ocr", False),
                "page_num":    block.get("page_num", 0),
                # 评论业务字段（用于过滤 / 分析）
                "site":         block.get("site", ""),
                "product_type": block.get("product_type", ""),
                "brand":        block.get("brand", ""),
                "model":        block.get("model", ""),
                "form_factor":  block.get("form_factor", ""),
                "rating":       block.get("rating", 0),
                "country":      block.get("country", ""),
                "verified":     block.get("verified", False),
                "date":         block.get("date", ""),
                "asin":         block.get("asin", ""),
                "helpful_votes": block.get("helpful_votes", 0),
                "vine_voice":   block.get("vine_voice", False),
            }
        }


# ── 策略：固定大小分块（消融对比用） ──────────────────────────────────────────

def chunk_fixed(
    text: str,
    chunk_size: int = 500,
    overlap: int = 50,
) -> Iterator[str]:
    """按字符数切块，相邻块有重叠。会切断评论，仅用于对比实验。"""
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        yield text[start:end]
        start += chunk_size - overlap


# ── 主流程 ────────────────────────────────────────────────────────────────────

STRATEGY = "per_review"   # 评论数据默认用此策略


def build_chunk_id(prefix: str, idx: int) -> str:
    return f"thermal_{prefix}_{idx:05d}"


def process_file(parsed_path: Path, strategy: str = STRATEGY):
    with open(parsed_path, encoding="utf-8") as f:
        data = json.load(f)

    meta   = data.get("meta", {})
    blocks = data.get("blocks", [])

    logger.info(f"分块 {parsed_path.name}  策略={strategy}  blocks={len(blocks)}")

    raw_chunks = []

    if strategy == "per_review":
        for chunk in chunk_per_review(blocks):
            raw_chunks.append(chunk)

    elif strategy == "fixed":
        full_text = "\n\n".join(b["content"] for b in blocks if b["content"].strip())
        for text_chunk in chunk_fixed(full_text):
            raw_chunks.append({
                "content":  text_chunk,
                "metadata": {
                    "block_types": ["text"],
                    "is_ocr":      False,
                    "section":     "",
                    "page_num":    0,
                    "site": "", "product_type": "", "brand": "",
                    "model": "", "form_factor": "", "rating": 0,
                    "country": "", "verified": False, "date": "",
                    "asin": "", "helpful_votes": 0, "vine_voice": False,
                }
            })

    else:
        raise ValueError(f"未知策略: {strategy}")

    # 补充公共元信息
    result = []
    for idx, chunk in enumerate(raw_chunks):
        chunk["chunk_id"] = build_chunk_id(meta.get("source", "amazon"), idx)
        chunk["metadata"]["strategy"]    = strategy
        chunk["metadata"]["source_file"] = parsed_path.name
        # 兼容 build_index.py 的字段名
        chunk["metadata"]["stock_code"]  = chunk["metadata"]["brand"]
        chunk["metadata"]["year"]        = chunk["metadata"]["date"][:4] if chunk["metadata"]["date"] else ""
        chunk["metadata"]["section"]     = chunk["metadata"]["section"]
        chunk["metadata"]["block_types"] = chunk["metadata"]["block_types"]
        chunk["metadata"]["is_ocr"]      = chunk["metadata"]["is_ocr"]
        result.append(chunk)

    # 保存
    out_path = CHUNKS_DIR / f"{parsed_path.stem}_{strategy}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    logger.info(f"  → {len(result)} 个 chunk，已保存 {out_path.name}")
    return result


def main():
    parsed_files = list(PARSED_DIR.glob("*.json"))
    if not parsed_files:
        logger.error("没有找到解析结果，请先运行 parse_xlsx.py")
        return

    # 只处理 xlsx 解析出的文件（含 Review 关键词）
    review_files = [p for p in parsed_files if "Review" in p.stem or "review" in p.stem]
    if not review_files:
        logger.warning("未找到评论数据解析文件，尝试全部 parsed 文件")
        review_files = parsed_files

    all_chunks = []
    for path in review_files:
        chunks = process_file(path, strategy=STRATEGY)
        all_chunks.extend(chunks)

    combined_path = CHUNKS_DIR / f"all_{STRATEGY}.json"
    with open(combined_path, "w", encoding="utf-8") as f:
        json.dump(all_chunks, f, ensure_ascii=False, indent=2)

    logger.info(f"\n合并完成：共 {len(all_chunks)} 个 chunk → {combined_path}")

    avg_len = sum(len(c["content"]) for c in all_chunks) / max(len(all_chunks), 1)
    logger.info(f"平均 chunk 长度: {avg_len:.0f} 字符")

    # 统计
    brands = set(c["metadata"]["brand"] for c in all_chunks if c["metadata"]["brand"])
    types  = set(c["metadata"]["product_type"] for c in all_chunks if c["metadata"]["product_type"])
    forms  = set(c["metadata"]["form_factor"] for c in all_chunks if c["metadata"]["form_factor"])
    sites  = set(c["metadata"]["site"] for c in all_chunks if c["metadata"]["site"])
    logger.info(f"品牌: {len(brands)} 个 | 产品类型: {len(types)} 个 | 形态: {len(forms)} 个 | 站点: {len(sites)} 个")


if __name__ == "__main__":
    main()
