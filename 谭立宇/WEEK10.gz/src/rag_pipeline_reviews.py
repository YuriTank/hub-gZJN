"""
热成像评论 RAG 问答流水线

流程与 rag_pipeline.py 一致，但专为热成像评论数据定制：
  - 向量库指向 vectorstore/reviews/（兼容 FAISS + BM25）
  - 元数据过滤支持 brand / product_type / form_factor / site / country
  - Prompt 面向评论分析场景（用户群体、好评分布、关注维度）

使用方式：
  python rag_pipeline_reviews.py                              # 交互式
  python rag_pipeline_reviews.py --query "FLIR 用户群体"       # 单次查询
  python rag_pipeline_reviews.py --query "..." --brand FLIR --form-factor handheld
  python rag_pipeline_reviews.py --query "..." --country US   # 按国家过滤
  python rag_pipeline_reviews.py --query "..." --query-rewrite
  python rag_pipeline_reviews.py --query "..." --no-bm25 --no-rerank

依赖：
  pip install faiss-cpu rank_bm25 jieba openai numpy sentence-transformers
  export DEEPSEEK_API_KEY="sk-xxx"
"""

import os
import json
import logging
import argparse
import numpy as np
from pathlib import Path
from typing import Optional
from openai import OpenAI
from sentence_transformers import SentenceTransformer

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

BASE_DIR        = Path(__file__).parent.parent
VECTORSTORE_DIR = BASE_DIR / "vectorstore" / "reviews"
MODELS_DIR      = BASE_DIR / "models"
BGE_MODEL_PATH  = MODELS_DIR / "bge-small-zh-v1.5"
INDEX_PATH      = VECTORSTORE_DIR / "faiss_index.bin"
META_PATH       = VECTORSTORE_DIR / "faiss_meta.json"

LLM_BASE_URL    = "https://api.deepseek.com"
EMBED_DIM       = 512
LLM_MODEL       = "deepseek-v4-pro"

TOP_K_RETRIEVE  = 15
TOP_K_RERANK    = 5
SCORE_THRESHOLD = 0.20

SYSTEM_PROMPT = """你是一个专业的亚马逊热成像产品评论分析助手，专门回答关于热成像产品用户反馈的问题。

回答规则：
1. 只根据【参考资料】中的评论内容回答，不得编造数据
2. 若参考资料不足以支撑回答，直接说"根据提供的评论数据无法回答此问题"
3. 引用具体评论时在句末标注来源编号，如：多数用户认为画质清晰[1]
4. 回答要结构化：先给结论，再列依据（分点说明）
5. 涉及产品信息时标注品牌、型号、产品类型"""


# ── DeepSeek LLM 客户端 ──────────────────────────────────────────────────────

def get_client() -> OpenAI:
    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key:
        raise EnvironmentError(
            "请设置环境变量 DEEPSEEK_API_KEY\n"
            "  export DEEPSEEK_API_KEY=sk-xxx"
        )
    return OpenAI(api_key=api_key, base_url=LLM_BASE_URL)


# ── 本地 BGE Embedding 模型 ──────────────────────────────────────────────────

def get_embedding_model() -> SentenceTransformer:
    model_path = str(BGE_MODEL_PATH) if BGE_MODEL_PATH.exists() else "BAAI/bge-small-zh-v1.5"
    logger.info(f"加载 embedding 模型: {model_path}")
    return SentenceTransformer(model_path, device="cpu")


# ── 向量检索 ──────────────────────────────────────────────────────────────────

class VectorStore:
    def __init__(self, embed_model: SentenceTransformer):
        import faiss
        self.embed_model = embed_model
        self.index       = faiss.read_index(str(INDEX_PATH))
        with open(META_PATH, encoding="utf-8") as f:
            self.meta_list = json.load(f)
        logger.info(f"FAISS 索引加载完成，共 {self.index.ntotal} 条向量")

    def _embed_query(self, query: str) -> np.ndarray:
        vec = self.embed_model.encode([query], normalize_embeddings=True, convert_to_numpy=True)
        return vec.astype("float32")

    def search(
        self,
        query: str,
        top_k: int = TOP_K_RETRIEVE,
        filter_meta: Optional[dict] = None,
    ) -> list[dict]:
        """
        向量检索，可选元数据过滤。
        filter_meta 示例：
          {"brand": "FLIR", "form_factor": "mobile_module"}
          {"product_type": "低端手持96", "country": "US"}
        """
        query_vec = self._embed_query(query)
        scores, indices = self.index.search(query_vec, top_k * 4)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0 or idx >= len(self.meta_list):
                continue
            item = dict(self.meta_list[idx])
            item["vec_score"] = float(score)

            if filter_meta:
                if not all(str(item.get(k, "")) == str(v) for k, v in filter_meta.items()):
                    continue

            results.append(item)
            if len(results) >= top_k:
                break
        return results


# ── BM25 关键词检索 ───────────────────────────────────────────────────────────

class BM25Store:
    def __init__(self):
        from rank_bm25 import BM25Okapi
        import jieba

        with open(META_PATH, encoding="utf-8") as f:
            self.meta_list = json.load(f)

        logger.info("构建 BM25 索引（分词中，请稍候）...")
        tokenized   = [list(jieba.cut(item["content"])) for item in self.meta_list]
        self.bm25   = BM25Okapi(tokenized)
        self.jieba  = jieba
        logger.info("BM25 索引完成")

    def search(self, query: str, top_k: int = TOP_K_RETRIEVE) -> list[dict]:
        tokens = list(self.jieba.cut(query))
        scores = self.bm25.get_scores(tokens)
        top_idx = np.argsort(scores)[::-1][:top_k]

        results = []
        for idx in top_idx:
            if scores[idx] < 1e-9:
                continue
            item = dict(self.meta_list[idx])
            item["bm25_score"] = float(scores[idx])
            results.append(item)
        return results


# ── RRF 融合 ──────────────────────────────────────────────────────────────────

def reciprocal_rank_fusion(
    vec_results: list[dict],
    bm25_results: list[dict],
    k: int = 60,
) -> list[dict]:
    rrf_scores: dict[str, float] = {}
    chunk_map:  dict[str, dict]  = {}

    for rank, item in enumerate(vec_results, 1):
        cid = item["chunk_id"]
        rrf_scores[cid] = rrf_scores.get(cid, 0) + 1 / (k + rank)
        chunk_map[cid]  = item

    for rank, item in enumerate(bm25_results, 1):
        cid = item["chunk_id"]
        rrf_scores[cid] = rrf_scores.get(cid, 0) + 1 / (k + rank)
        chunk_map[cid]  = item

    sorted_cids = sorted(rrf_scores, key=lambda x: -rrf_scores[x])
    results = []
    for cid in sorted_cids:
        item = dict(chunk_map[cid])
        item["rrf_score"] = rrf_scores[cid]
        results.append(item)
    return results


# ── CrossEncoder Rerank（可选）────────────────────────────────────────────────

def rerank(query: str, candidates: list[dict], top_k: int = TOP_K_RERANK) -> list[dict]:
    try:
        from sentence_transformers import CrossEncoder
        model_path = Path(__file__).parent.parent / "models" / "bge-reranker-base"
        model_name = str(model_path) if model_path.exists() else "BAAI/bge-reranker-base"
        reranker = CrossEncoder(model_name)
        pairs    = [(query, c["content"]) for c in candidates]
        scores   = reranker.predict(pairs)
        for item, score in zip(candidates, scores):
            item["rerank_score"] = float(score)
        candidates.sort(key=lambda x: -x.get("rerank_score", 0))
    except ImportError:
        logger.warning("sentence-transformers 未安装，跳过 Rerank（pip install sentence-transformers）")
    except Exception as e:
        logger.warning(f"Rerank 失败，使用 RRF 原始排序: {e}")

    return candidates[:top_k]


# ── 查询改写 ──────────────────────────────────────────────────────────────────

def rewrite_query(query: str, client: OpenAI) -> str:
    resp = client.chat.completions.create(
        model=LLM_MODEL,
        messages=[
            {
                "role": "system",
                "content": (
                    "你是检索查询优化专家。将用户的问题改写为更适合从评论数据中检索信息的查询语句。"
                    "保留关键实体（品牌、型号、产品类型），扩展相关关键词，不要超过50字。"
                    "直接输出改写后的查询语句，不要解释。"
                ),
            },
            {"role": "user", "content": query},
        ],
        temperature=0,
    )
    rewritten = resp.choices[0].message.content.strip()
    logger.info(f"查询改写: {query!r} → {rewritten!r}")
    return rewritten


# ── LLM 生成 ──────────────────────────────────────────────────────────────────

def build_context(retrieved: list[dict]) -> tuple[str, list[dict]]:
    parts     = []
    citations = []

    for i, item in enumerate(retrieved, 1):
        brand   = item.get("brand", "")
        model   = item.get("model", "")
        ptype   = item.get("product_type", "")
        ff      = item.get("form_factor", "")
        site    = item.get("site", "")
        rating  = item.get("rating", "")
        country = item.get("country", "")
        date    = item.get("date", "")

        label_parts = [f"[{i}]"]
        if brand:
            label_parts.append(brand)
        if model:
            label_parts.append(model)
        if ptype:
            label_parts.append(f"({ptype})")
        if rating:
            label_parts.append(f"★{rating}")
        if country:
            label_parts.append(country)
        if date:
            label_parts.append(date)
        label = " ".join(label_parts)

        content = item.get("content", "")
        parts.append(f"{label}\n{content}")
        citations.append({"index": i, "source": label, "chunk_id": item.get("chunk_id", "")})

    return "\n\n---\n\n".join(parts), citations


def call_llm(query: str, context: str, client: OpenAI) -> str:
    user_msg = (
        f"【参考资料】\n{context}\n\n"
        f"【问题】\n{query}\n\n"
        "请根据参考资料回答，并在引用数据处标注来源编号（如[1]）。"
    )
    resp = client.chat.completions.create(
        model=LLM_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": user_msg},
        ],
        temperature=0.1,
    )
    return resp.choices[0].message.content


# ── 完整流水线 ────────────────────────────────────────────────────────────────

class RAGPipeline:
    def __init__(
        self,
        use_bm25:        bool = True,
        use_rerank:      bool = True,
        use_query_rewrite: bool = False,
    ):
        self.client        = get_client()
        self.embed_model   = get_embedding_model()
        self.vec_store     = VectorStore(self.embed_model)
        self.use_bm25      = use_bm25
        self.use_rerank    = use_rerank
        self.use_qr        = use_query_rewrite
        self.bm25_store    = BM25Store() if use_bm25 else None

    def query(
        self,
        question: str,
        filter_meta: Optional[dict] = None,
        verbose: bool = False,
    ) -> dict:
        retrieval_query = rewrite_query(question, self.client) if self.use_qr else question

        vec_results = self.vec_store.search(retrieval_query, TOP_K_RETRIEVE, filter_meta)
        if verbose:
            logger.info(f"向量召回: {len(vec_results)} 条，最高分={vec_results[0]['vec_score']:.3f}" if vec_results else "向量召回: 0 条")

        if self.use_bm25 and self.bm25_store:
            bm25_results = self.bm25_store.search(retrieval_query, TOP_K_RETRIEVE)
            candidates   = reciprocal_rank_fusion(vec_results, bm25_results)
            if verbose:
                logger.info(f"BM25 召回: {len(bm25_results)} 条，RRF 后: {len(candidates)} 条")
        else:
            candidates = vec_results

        if self.use_rerank:
            final = rerank(question, candidates, TOP_K_RERANK)
        else:
            final = candidates[:TOP_K_RERANK]

        if verbose:
            logger.info(f"最终使用 {len(final)} 条上下文")

        if not final:
            return {"answer": "未找到相关评论，无法回答此问题。", "citations": [], "retrieved": []}

        top_score = final[0].get("vec_score", final[0].get("rerank_score", 1.0))
        if top_score < SCORE_THRESHOLD and filter_meta is None:
            return {
                "answer": "评论知识库中未找到与该问题高度相关的内容。",
                "citations": [], "retrieved": final,
            }

        context, citations = build_context(final)
        answer = call_llm(question, context, self.client)

        return {"answer": answer, "citations": citations, "retrieved": final}


# ── 入口 ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="热成像评论 RAG 问答")
    parser.add_argument("--query",          type=str,  default=None)
    parser.add_argument("--brand",          type=str,  default=None, help="品牌过滤，如 FLIR / TOPDON / HIKMICRO")
    parser.add_argument("--product-type",   type=str,  default=None, help="产品类型过滤：手机模组非96/低端手持96/点温仪")
    parser.add_argument("--form-factor",    type=str,  default=None, help="形态过滤：handheld / mobile_module / spot_thermometer")
    parser.add_argument("--country",        type=str,  default=None, help="国家过滤，如 US / DE / JP")
    parser.add_argument("--site",           type=str,  default=None, help="站点过滤，如 US / DE / A")
    parser.add_argument("--query-rewrite",  action="store_true", help="开启查询改写（增加一次 LLM 调用）")
    parser.add_argument("--no-bm25",        action="store_true", help="关闭 BM25（消融实验用）")
    parser.add_argument("--no-rerank",      action="store_true", help="关闭 Rerank（消融实验用）")
    args = parser.parse_args()

    pipeline = RAGPipeline(
        use_bm25         = not args.no_bm25,
        use_rerank       = not args.no_rerank,
        use_query_rewrite= args.query_rewrite,
    )

    filter_meta = {}
    if args.brand:        filter_meta["brand"]        = args.brand
    if args.product_type: filter_meta["product_type"] = args.product_type
    if args.form_factor:  filter_meta["form_factor"]  = args.form_factor
    if args.country:      filter_meta["country"]      = args.country
    if args.site:         filter_meta["site"]         = args.site
    if not filter_meta:
        filter_meta = None

    def print_result(q: str, result: dict):
        print(f"\n{'='*60}")
        print(f"问题：{q}")
        if filter_meta:
            print(f"过滤：{filter_meta}")
        print(f"{'='*60}")
        print(f"\n{result['answer']}")
        if result.get("citations"):
            print("\n── 来源 ──")
            for c in result["citations"]:
                print(f"  {c['source']}")

    if args.query:
        result = pipeline.query(args.query, filter_meta=filter_meta, verbose=True)
        print_result(args.query, result)
    else:
        print("热成像评论 RAG 问答系统")
        print(f"模型：{LLM_MODEL}  |  向量库：{INDEX_PATH}")
        print(f"共 9222 条评论 | 15 品牌 | 5 产品类型 | 14 站点")
        print("支持过滤参数：--brand / --product-type / --form-factor / --country / --site")
        print("输入 'exit' 退出，'mode' 查看当前配置\n")
        while True:
            try:
                q = input("问题：").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if not q:
                continue
            if q.lower() == "exit":
                break
            if q.lower() == "mode":
                print(f"BM25={'on' if pipeline.use_bm25 else 'off'}  "
                      f"Rerank={'on' if pipeline.use_rerank else 'off'}  "
                      f"QueryRewrite={'on' if pipeline.use_qr else 'off'}")
                continue
            result = pipeline.query(q, filter_meta=filter_meta, verbose=True)
            print_result(q, result)


if __name__ == "__main__":
    main()
