"""
评论向量索引构建脚本

与 build_index.py 模式一致，但专门为热成像评论数据定制：
  - 读取 chunk_reviews.py 输出的 all_per_review.json
  - FAISS 索引 + 丰富元数据（含 brand/product_type/site/country/rating 等过滤字段）
  - 索引文件保存在 vectorstore/reviews/ 目录，不与年报索引冲突

依赖：
  pip install faiss-cpu sentence-transformers numpy
"""

import json
import logging
import numpy as np
from pathlib import Path
from sentence_transformers import SentenceTransformer

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

BASE_DIR        = Path(__file__).parent.parent
CHUNKS_DIR      = BASE_DIR / "data" / "chunks"
VECTORSTORE_DIR = BASE_DIR / "vectorstore" / "reviews"
MODELS_DIR      = BASE_DIR / "models"
BGE_MODEL_PATH  = MODELS_DIR / "bge-small-zh-v1.5"
VECTORSTORE_DIR.mkdir(parents=True, exist_ok=True)

STRATEGY   = "per_review"
CHUNKS_FILE = CHUNKS_DIR / f"all_{STRATEGY}.json"

EMBED_DIM  = 512
BATCH_SIZE = 256


def get_embedding_model() -> SentenceTransformer:
    model_path = str(BGE_MODEL_PATH) if BGE_MODEL_PATH.exists() else "BAAI/bge-small-zh-v1.5"
    logger.info(f"加载 embedding 模型: {model_path}")
    return SentenceTransformer(model_path, device="cpu")


def embed_texts(model: SentenceTransformer, texts: list[str], show_progress: bool = True) -> np.ndarray:
    raw = model.encode(
        texts,
        batch_size=BATCH_SIZE,
        show_progress_bar=show_progress,
        normalize_embeddings=True,
    )
    embeddings = np.asarray(raw, dtype="float32")
    if embeddings.ndim == 1:
        embeddings = embeddings.reshape(1, -1)
    return embeddings


def build_faiss_index(chunks: list[dict], model: SentenceTransformer):
    import faiss

    logger.info(f"开始计算 {len(chunks)} 条评论的 embedding...")
    texts = [c["content"] for c in chunks]
    empty_count = sum(1 for t in texts if not t.strip())
    if empty_count:
        logger.warning(f"  发现 {empty_count} 条空内容 chunk")
    embeddings = embed_texts(model, texts)
    logger.info(f"  embedding 完成，shape={embeddings.shape}")

    logger.info(f"构建 FAISS 索引，维度={EMBED_DIM}...")
    index = faiss.IndexFlatIP(EMBED_DIM)
    index.add(embeddings)
    logger.info(f"索引构建完成，共 {index.ntotal} 条向量")

    index_path = VECTORSTORE_DIR / "faiss_index.bin"
    meta_path  = VECTORSTORE_DIR / "faiss_meta.json"

    faiss.write_index(index, str(index_path))
    logger.info(f"FAISS 索引已保存 → {index_path}  ({index_path.stat().st_size // 1024} KB)")

    # 元数据：包含所有评论业务字段，rag_pipeline 中可据此做过滤
    meta_list = [
        {
            "chunk_id":   c["chunk_id"],
            "content":    c["content"],
            # 兼容字段（build_index.py 原有）
            "stock_code": c["metadata"].get("brand", ""),
            "year":       c["metadata"].get("year", ""),
            "page_num":   c["metadata"].get("page_num", -1),
            "section":    c["metadata"].get("section", ""),
            "block_types":c["metadata"].get("block_types", []),
            "is_ocr":     c["metadata"].get("is_ocr", False),
            "strategy":   c["metadata"].get("strategy", ""),
            "source_file":c["metadata"].get("source_file", ""),
            # 评论核心过滤字段
            "site":         c["metadata"].get("site", ""),
            "product_type": c["metadata"].get("product_type", ""),
            "brand":        c["metadata"].get("brand", ""),
            "model":        c["metadata"].get("model", ""),
            "form_factor":  c["metadata"].get("form_factor", ""),
            "rating":       c["metadata"].get("rating", 0),
            "country":      c["metadata"].get("country", ""),
            "verified":     c["metadata"].get("verified", False),
            "date":         c["metadata"].get("date", ""),
            "asin":         c["metadata"].get("asin", ""),
            "helpful_votes": c["metadata"].get("helpful_votes", 0),
            "vine_voice":   c["metadata"].get("vine_voice", False),
        }
        for c in chunks
    ]
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta_list, f, ensure_ascii=False, indent=2)
    logger.info(f"元数据已保存 → {meta_path}")

    return index, meta_list


def build_chroma_index(chunks: list[dict], model: SentenceTransformer):
    """ChromaDB 版本（可选），支持原生 metadata 过滤。"""
    try:
        import chromadb
    except ImportError:
        logger.error("请先安装 chromadb: pip install chromadb")
        return

    chroma_dir = VECTORSTORE_DIR / "chroma"
    client_db  = chromadb.PersistentClient(path=str(chroma_dir))
    collection = client_db.get_or_create_collection(
        name="thermal_reviews",
        metadata={"hnsw:space": "cosine"},
    )

    logger.info(f"向 ChromaDB 写入 {len(chunks)} 条评论...")
    texts      = [c["content"] for c in chunks]
    embeddings = embed_texts(model, texts)

    for i in range(0, len(chunks), 100):
        batch = chunks[i:i+100]
        ids   = [c["chunk_id"] for c in batch]
        docs  = [c["content"] for c in batch]
        embs  = embeddings[i:i+100].tolist()
        metas = []
        for c in batch:
            m = dict(c["metadata"])
            m["block_types"] = ",".join(m.get("block_types") or [])
            # ChromaDB 不支持 list，转成逗号分隔
            for k in ["section_path"]:
                m.pop(k, None)
            metas.append(m)
        collection.add(documents=docs, embeddings=embs, ids=ids, metadatas=metas)
        logger.info(f"  已写入 {min(i+100, len(chunks))}/{len(chunks)}")

    logger.info(f"ChromaDB 写入完成，共 {collection.count()} 条")


def main():
    if not CHUNKS_FILE.exists():
        logger.error(f"找不到 {CHUNKS_FILE}，请先运行 chunk_reviews.py")
        return

    with open(CHUNKS_FILE, encoding="utf-8") as f:
        chunks = json.load(f)
    logger.info(f"加载 {len(chunks)} 个 chunks（策略={STRATEGY}）")

    model = get_embedding_model()

    build_faiss_index(chunks, model)

    # 若要对比 ChromaDB，取消下行注释：
    # build_chroma_index(chunks, model)

    logger.info("\n评论索引构建完成！")
    logger.info(f"  FAISS 索引: {VECTORSTORE_DIR / 'faiss_index.bin'}")
    logger.info(f"  元数据:     {VECTORSTORE_DIR / 'faiss_meta.json'}")
    logger.info(f"\n共 {len(chunks)} 条评论，维度 {EMBED_DIM}")


if __name__ == "__main__":
    main()
