"""
XLSX 解析脚本：将亚马逊热成像评论数据表转换为结构化文本

与 parse_pdf.py 的设计一致，输出统一的 ParsedBlock 格式，
后续可复用 chunk_documents.py / build_index.py / rag_pipeline.py 等流程。

数据源：竞品Review分析_final.xlsx → Review数据 Sheet（9238条）
业务字段：站点/产品类型/品牌/型号/Review原文翻译/ASIN/标题/内容/星级/所属国家等

依赖安装：
  pip install pandas openpyxl
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Optional

import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

RAW_DIR    = Path(__file__).parent.parent / "data" / "raw_xlsx"
PARSED_DIR = Path(__file__).parent.parent / "data" / "parsed"
PARSED_DIR.mkdir(parents=True, exist_ok=True)


# ── 产品类型 → 形态映射 ───────────────────────────────────────────────────────

PRODUCT_TYPE_MAP: dict[str, str] = {
    "手机模组非96": "mobile_module",
    "手机模组96":   "mobile_module",
    "低端手持96":   "handheld",
    "低端手持非96": "handheld",
    "点温仪":       "spot_thermometer",
}


# ── 数据结构 ──────────────────────────────────────────────────────────────────

@dataclass
class ParsedBlock:
    """
    一个解析块 = 一条评论的结构化表示

    block_type: "review"
    content:    中文翻译（Review原文翻译）为主，附原文标题+正文
    section_path: [产品类型, 品牌, 型号] 层级路径
    """
    block_type:   str
    content:      str
    page_num:     int
    section_path: list[str]
    is_ocr:       bool = False

    # 核心业务字段
    site:         str = ""          # 亚马逊站点（DE/US/FR/CA...）
    product_type: str = ""          # 产品类型（手机模组非96/低端手持96/点温仪...）
    brand:        str = ""          # 品牌
    model:        str = ""          # 具体型号
    form_factor:  str = ""          # mobile_module / handheld / spot_thermometer
    rating:       float = 0.0       # 1-5 星
    country:      str = ""          # 评论者国家
    verified:     bool = False      # 是否验证购买
    date:         str = ""          # 评论日期
    asin:         str = ""          # Amazon ASIN
    helpful_votes: int = 0          # 赞同数
    vine_voice:   bool = False      # Vine Voice 评论

    # 原文（用于 RAG 上下文增强）
    original_title: str = ""
    original_body:  str = ""


# ── 字段映射 ──────────────────────────────────────────────────────────────────
# KEY=内部字段, VALUE=[可能出现的列名]

COLUMN_MAP: dict[str, list[str]] = {
    "site":          ["站点"],
    "product_type":  ["产品类型"],
    "brand":         ["品牌"],
    "model":         ["型号", "产品型号"],
    "translated":    ["review原文翻译"],
    "asin":          ["asin"],
    "title":         ["标题"],
    "body":          ["内容"],
    "verified":      ["vp评论"],
    "vine_voice":    ["vine voice评论"],
    "variant":       ["型号.1"],
    "rating":        ["星级"],
    "helpful_votes": ["赞同数"],
    "country":       ["所属国家"],
    "date":          ["评论时间"],
    "review_link":   ["评论链接"],
    "reviewer":      ["评论人"],
}


def _match_column(df: pd.DataFrame, field: str) -> Optional[str]:
    candidates = COLUMN_MAP.get(field, [])
    for col in df.columns:
        col_clean = col.strip().lower()
        for cand in candidates:
            if cand.lower() == col_clean:
                return col
    return None


# ── 工具函数 ──────────────────────────────────────────────────────────────────

def _parse_rating(val) -> float:
    try:
        return float(val)
    except (ValueError, TypeError):
        return 0.0


def _parse_verified(val) -> bool:
    if isinstance(val, str):
        return val.strip().upper() == "Y"
    return bool(val)


def _parse_date(val) -> str:
    if pd.isna(val):
        return ""
    if isinstance(val, (int, float)):
        try:
            dt = datetime(1899, 12, 30) + timedelta(days=int(val))
            return dt.strftime("%Y-%m-%d")
        except (ValueError, OverflowError):
            return str(val)
    return str(val).strip()


def _parse_int(val) -> int:
    try:
        return int(float(val))
    except (ValueError, TypeError):
        return 0


# ── 有效 Sheet ────────────────────────────────────────────────────────────────

VALID_SHEETS = {"Review数据"}


# ── 解析器 ────────────────────────────────────────────────────────────────────

class ReviewParser:

    def __init__(self, xlsx_path: Path, meta: dict = None):
        self.xlsx_path = xlsx_path
        self.meta      = meta or {}
        self.blocks: list[ParsedBlock] = []

    def _parse_main_sheet(self, df: pd.DataFrame, sheet_name: str = ""):
        """
        解析"Review数据"主表（9238行）。
        """
        col_site       = _match_column(df, "site")
        col_ptype      = _match_column(df, "product_type")
        col_brand      = _match_column(df, "brand")
        col_model      = _match_column(df, "model")
        col_translated = _match_column(df, "translated")
        col_asin       = _match_column(df, "asin")
        col_title      = _match_column(df, "title")
        col_body       = _match_column(df, "body")
        col_verified   = _match_column(df, "verified")
        col_vine       = _match_column(df, "vine_voice")
        col_rating     = _match_column(df, "rating")
        col_helpful    = _match_column(df, "helpful_votes")
        col_country    = _match_column(df, "country")
        col_date       = _match_column(df, "date")

        # 必须有翻译或原文才能产出
        if not col_translated and not col_body:
            logger.warning(f"  Sheet [{sheet_name}] 无翻译列和正文列，跳过")
            return

        row_count = 0
        for idx, row in df.iterrows():
            # 取中文翻译为主，原文为辅
            trans_val = str(row[col_translated]).strip() if col_translated and pd.notna(row[col_translated]) else ""
            body_val  = str(row[col_body]).strip()       if col_body       and pd.notna(row[col_body])       else ""

            if not trans_val and len(body_val) < 5:
                continue

            # 构建内容：中文翻译 + 英文原文（摘要）
            content_parts = []
            if trans_val:
                content_parts.append(trans_val)
            if body_val and body_val != trans_val:
                # 仅附原文前 200 字符作为补充
                content_parts.append(f"[EN] {body_val[:200]}")
            content = "\n".join(content_parts)

            site_val     = str(row[col_site]).strip()    if col_site    and pd.notna(row[col_site])    else ""
            ptype_val    = str(row[col_ptype]).strip()   if col_ptype   and pd.notna(row[col_ptype])   else ""
            brand_val    = str(row[col_brand]).strip()   if col_brand   and pd.notna(row[col_brand])   else ""
            model_val    = str(row[col_model]).strip()   if col_model   and pd.notna(row[col_model])   else ""
            asin_val     = str(row[col_asin]).strip()    if col_asin    and pd.notna(row[col_asin])    else ""
            title_val    = str(row[col_title]).strip()   if col_title   and pd.notna(row[col_title])   else ""
            rating_val   = _parse_rating(row[col_rating])   if col_rating  and pd.notna(row[col_rating]) else 0.0
            verified_val = _parse_verified(row[col_verified]) if col_verified and pd.notna(row[col_verified]) else False
            vine_val     = _parse_verified(row[col_vine])    if col_vine    and pd.notna(row[col_vine])    else False
            helpful_val  = _parse_int(row[col_helpful])      if col_helpful and pd.notna(row[col_helpful]) else 0
            country_val  = str(row[col_country]).strip() if col_country and pd.notna(row[col_country]) else ""
            date_val     = _parse_date(row[col_date])    if col_date    and pd.notna(row[col_date])    else ""

            form_factor = PRODUCT_TYPE_MAP.get(ptype_val, "")

            # section_path = [产品类型, 品牌, 型号]
            section_parts = [p for p in [ptype_val, brand_val, model_val] if p]

            block = ParsedBlock(
                block_type="review",
                content=content,
                page_num=0,
                section_path=section_parts,
                site=site_val,
                product_type=ptype_val,
                brand=brand_val,
                model=model_val,
                form_factor=form_factor,
                rating=rating_val,
                country=country_val,
                verified=verified_val,
                date=date_val,
                asin=asin_val,
                helpful_votes=helpful_val,
                vine_voice=vine_val,
                original_title=title_val,
                original_body=body_val,
            )
            self.blocks.append(block)
            row_count += 1

        logger.info(f"  Sheet [{sheet_name}] 解析完成: {row_count} 条评论")
        return row_count

    def parse(self) -> list[ParsedBlock]:
        logger.info(f"开始解析: {self.xlsx_path.name}")

        excel_file = pd.ExcelFile(self.xlsx_path)
        available_sheets = excel_file.sheet_names

        sheets_to_read = [s for s in available_sheets if s in VALID_SHEETS]
        skipped = [s for s in available_sheets if s not in VALID_SHEETS]
        if skipped:
            logger.info(f"  跳过非评论 Sheet: {skipped}")

        if not sheets_to_read:
            logger.warning(f"  未找到有效 Sheet {VALID_SHEETS}，可用: {available_sheets}")
            return self.blocks

        for sn in sheets_to_read:
            df = pd.read_excel(self.xlsx_path, sheet_name=sn)
            if df.empty:
                continue
            self._parse_main_sheet(df, sheet_name=sn)

        logger.info(f"  全部解析完成: 共 {len(self.blocks)} 条评论（{len(sheets_to_read)} 个 Sheet）")
        return self.blocks

    def save(self):
        stem     = self.xlsx_path.stem
        out_path = PARSED_DIR / f"{stem}.json"

        output = {
            "meta":   self.meta,
            "source": str(self.xlsx_path),
            "blocks": [asdict(b) for b in self.blocks],
        }
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(output, f, ensure_ascii=False, indent=2)
        logger.info(f"  已保存 → {out_path}  ({len(self.blocks)} 条评论)")


# ── 主流程 ────────────────────────────────────────────────────────────────────

def main():
    manifest_path = RAW_DIR.parent / "manifest_xlsx.json"

    if manifest_path.exists():
        with open(manifest_path, encoding="utf-8") as f:
            manifest = json.load(f)
    else:
        manifest = [
            {"filename": p.name, "source": "amazon", "category": "thermal"}
            for p in sorted(RAW_DIR.glob("*.xlsx"))
        ]

    if not manifest:
        logger.error(f"没有找到 XLSX 文件，请放入 {RAW_DIR}/")
        return

    for item in manifest:
        xlsx_path = RAW_DIR / item["filename"]
        if not xlsx_path.exists():
            logger.warning(f"文件不存在，跳过: {xlsx_path}")
            continue

        parser = ReviewParser(xlsx_path, meta=item)
        parser.parse()
        parser.save()

    logger.info(f"\n全部解析完成，结果在 {PARSED_DIR}")
    logger.info("后续执行: python src/chunk_documents.py  →  python src/build_index.py  →  python src/rag_pipeline.py")


if __name__ == "__main__":
    main()
