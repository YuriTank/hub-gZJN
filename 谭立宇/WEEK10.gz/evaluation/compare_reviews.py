"""
热成像评论消融实验脚本：对比不同检索方式和管道配置的效果

实验矩阵：
  检索方式: vector_only / hybrid（向量+BM25）
  Rerank:  on / off
  Pipeline: native（BM25+Vec+RRF）/ langchain（纯Vec）

每种组合用相同的 15 道题测试，
计算检索层面的指标（不依赖 RAGAS，更快）：
  - Hit Rate @5：前5个召回结果中，是否包含目标品牌/形态的评论
  - MRR（Mean Reciprocal Rank）：第一个命中的平均倒数排名

使用方式：
  python compare_reviews.py
  python compare_reviews.py --modes vector_only,hybrid
  python compare_reviews.py --top-k 3

依赖：
  pip install faiss-cpu openai jieba rank_bm25 sentence-transformers
"""

import os
import sys
import json
import argparse
import logging
import numpy as np
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

BASE_DIR      = Path(__file__).parent.parent
EVAL_DIR      = Path(__file__).parent
RESULT_DIR    = EVAL_DIR / "results"
RESULT_DIR.mkdir(exist_ok=True)

ABLATION_QUESTION_IDS = [1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13]


# ── 加载题集 ──────────────────────────────────────────────────────────────────

def load_ablation_questions() -> list[dict]:
    qpath = EVAL_DIR / "questions_reviews.json"
    with open(qpath, encoding="utf-8") as f:
        data = json.load(f)
    return [q for q in data["questions"] if q["id"] in ABLATION_QUESTION_IDS]


# ── 加载原生版索引（FAISS + Meta）────────────────────────────────────────────

def load_native_index():
    import faiss

    vs_dir     = BASE_DIR / "vectorstore" / "reviews"
    index_path = vs_dir / "faiss_index.bin"
    meta_path  = vs_dir / "faiss_meta.json"

    if not index_path.exists():
        raise FileNotFoundError(f"找不到原生版索引: {index_path}\n请先运行 src/build_index_reviews.py")

    index     = faiss.read_index(str(index_path))
    with open(meta_path, encoding="utf-8") as f:
        meta_list = json.load(f)
    logger.info(f"加载原生版索引: {index.ntotal} 条向量")
    return index, meta_list


# ── Embedding 查询（复用原生版 BGE 模型） ────────────────────────────────────

_embed_model = None

def get_embed_model():
    global _embed_model
    if _embed_model is None:
        from sentence_transformers import SentenceTransformer
        model_path = BASE_DIR / "models" / "bge-small-zh-v1.5"
        _embed_model = SentenceTransformer(
            str(model_path) if model_path.exists() else "BAAI/bge-small-zh-v1.5",
            device="cpu",
        )
    return _embed_model


def embed_query(query: str) -> np.ndarray:
    model = get_embed_model()
    vec   = model.encode([query], normalize_embeddings=True, convert_to_numpy=True)
    return vec.astype("float32")


# ── 三种检索方式 ──────────────────────────────────────────────────────────────

def retrieve_vector(query: str, index, meta_list: list, top_k: int = 10) -> list[dict]:
    q_vec          = embed_query(query)
    scores, indices = index.search(q_vec, top_k * 2)
    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx < 0: continue
        item = dict(meta_list[idx])
        item["_score"] = float(score)
        results.append(item)
    return results[:top_k]


def retrieve_bm25(query: str, meta_list: list, top_k: int = 10) -> list[dict]:
    import jieba
    from rank_bm25 import BM25Okapi
    tokenized = [list(jieba.cut(m["content"])) for m in meta_list]
    bm25      = BM25Okapi(tokenized)
    tokens    = list(jieba.cut(query))
    scores    = bm25.get_scores(tokens)
    top_idx   = np.argsort(scores)[::-1][:top_k]
    results   = []
    for idx in top_idx:
        if scores[idx] < 1e-9: continue
        item = dict(meta_list[idx])
        item["_score"] = float(scores[idx])
        results.append(item)
    return results


def retrieve_hybrid(query: str, index, meta_list: list, top_k: int = 10) -> list[dict]:
    vec_res  = retrieve_vector(query, index, meta_list, top_k)
    bm25_res = retrieve_bm25(query, meta_list, top_k)

    rrf_scores: dict[str, float] = {}
    chunk_map:  dict[str, dict]  = {}
    k = 60

    for rank, item in enumerate(vec_res, 1):
        cid = item["chunk_id"]
        rrf_scores[cid] = rrf_scores.get(cid, 0) + 1 / (k + rank)
        chunk_map[cid]  = item

    for rank, item in enumerate(bm25_res, 1):
        cid = item["chunk_id"]
        rrf_scores[cid] = rrf_scores.get(cid, 0) + 1 / (k + rank)
        chunk_map[cid]  = item

    sorted_cids = sorted(rrf_scores, key=lambda x: -rrf_scores[x])
    return [chunk_map[cid] for cid in sorted_cids[:top_k]]


# ── 检索指标计算 ──────────────────────────────────────────────────────────────

def compute_metrics(
    questions: list[dict],
    index,
    meta_list: list,
    retrieval_mode: str,
    top_k: int = 5,
) -> dict:
    """
    计算：
      hit_rate@k：目标品牌出现在 top-k 中的比例
      mrr@k：平均倒数排名
    """
    hits = []
    mrrs = []

    for q in questions:
        target_docs = q.get("target_docs", [])
        if not target_docs:
            continue

        if retrieval_mode == "vector_only":
            retrieved = retrieve_vector(q["question"], index, meta_list, top_k)
        elif retrieval_mode == "bm25_only":
            retrieved = retrieve_bm25(q["question"], meta_list, top_k)
        else:
            retrieved = retrieve_hybrid(q["question"], index, meta_list, top_k)

        hit_any = False
        first_rank = None
        for i, item in enumerate(retrieved, 1):
            brand = item.get("brand", "")
            model = item.get("model", "")
            form_factor = item.get("form_factor", "")
            product_type = item.get("product_type", "")

            # 匹配任何 target_doc（可以是品牌名、形态名、产品类型）
            for td in target_docs:
                if td.lower() in brand.lower() or td.lower() in model.lower() or td.lower() in form_factor.lower() or td.lower() in product_type.lower():
                    hit_any = True
                    if first_rank is None:
                        first_rank = i
                    break

        hits.append(1 if hit_any else 0)
        mrrs.append(1 / first_rank if first_rank else 0)

    return {
        "hit_rate":  float(np.mean(hits)) if hits else 0.0,
        "mrr":       float(np.mean(mrrs)) if mrrs else 0.0,
        "n_questions": len(hits),
    }


# ── 主实验循环 ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="热成像评论消融实验")
    parser.add_argument("--modes", type=str, default="vector_only,hybrid",
                        help="逗号分隔的检索方式: vector_only,bm25_only,hybrid")
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()

    modes = [m.strip() for m in args.modes.split(",")]
    questions = load_ablation_questions()
    logger.info(f"消融实验: {len(questions)} 道题  检索方式={modes}")

    # 加载原生版索引
    try:
        index, meta_list = load_native_index()
    except FileNotFoundError as e:
        logger.error(str(e))
        return

    all_results = []

    for mode in modes:
        logger.info(f"  检索方式: {mode}")
        metrics = compute_metrics(questions, index, meta_list, mode, args.top_k)
        result  = {
            "retrieval_mode": mode,
            "hit_rate":     metrics["hit_rate"],
            "mrr":          metrics["mrr"],
            "n_questions":  metrics["n_questions"],
        }
        all_results.append(result)
        logger.info(f"    Hit@{args.top_k}={metrics['hit_rate']:.3f}  MRR={metrics['mrr']:.3f}")

    # 输出汇总
    if all_results:
        print(f"\n{'='*60}")
        print(f"热成像评论消融实验（Top-{args.top_k}）")
        print(f"{'='*60}")
        print(f"{'检索方式':<20} {'Hit Rate':>10} {'MRR':>10} {'题数':>6}")
        print(f"{'-'*60}")
        for r in sorted(all_results, key=lambda x: -x["hit_rate"]):
            print(f"{r['retrieval_mode']:<20} {r['hit_rate']:>10.3f} {r['mrr']:>10.3f} {r['n_questions']:>6}")
        print(f"{'='*60}")

        out_path = RESULT_DIR / "ablation_reviews.json"
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(all_results, f, ensure_ascii=False, indent=2)
        logger.info(f"结果已保存 → {out_path}")


if __name__ == "__main__":
    main()
