"""
热成像评论 RAGAS 自动化评估脚本（无 RAGAS 依赖版）

对原生版（src/rag_pipeline_reviews.py）和 LangChain 版（src_langchain/rag_chain_lc_reviews.py）
进行标准化评测，通过 DeepSeek API 直接计算 4 项指标：
  - Faithfulness（忠实度）：答案是否不矛盾于检索上下文
  - Answer Relevancy（答案相关性）：答案是否匹配问题
  - Context Precision（上下文精确率）：检索结果是否包含必要信息
  - Context Recall（上下文召回率）：全部必要信息是否被召回

使用方式：
  python evaluate_reviews.py --pipeline native       # 评估原生版
  python evaluate_reviews.py --pipeline langchain    # 评估 LangChain 版
  python evaluate_reviews.py --pipeline both         # 两版对比
  python evaluate_reviews.py --pipeline native --question-ids 1,2,3

依赖：
  export DEEPSEEK_API_KEY="sk-xxx"
  pip install openai datasets
"""

import os
import sys
import json
import argparse
import logging
import numpy as np
from pathlib import Path
from openai import OpenAI

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

BASE_DIR   = Path(__file__).parent.parent
EVAL_DIR   = Path(__file__).parent
RESULT_DIR = EVAL_DIR / "results"
RESULT_DIR.mkdir(exist_ok=True)

DEEPSEEK_URL = "https://api.deepseek.com"
LLM_MODEL    = "deepseek-v4-flash"

_client = None

def get_client() -> OpenAI:
    global _client
    if _client is None:
        key = os.getenv("DEEPSEEK_API_KEY") or os.getenv("OPENAI_API_KEY")
        if not key:
            raise ValueError(
                "请设置 DEEPSEEK_API_KEY 或 OPENAI_API_KEY 环境变量\n"
                "  export DEEPSEEK_API_KEY=sk-xxx"
            )
        _client = OpenAI(api_key=key, base_url=DEEPSEEK_URL)
    return _client


# ── 加载评测题集 ──────────────────────────────────────────────────────────────

def load_questions(question_ids: list[int] = None) -> list[dict]:
    qpath = EVAL_DIR / "questions_reviews.json"
    with open(qpath, encoding="utf-8") as f:
        data = json.load(f)
    questions = data["questions"]
    if question_ids:
        questions = [q for q in questions if q["id"] in question_ids]
    return questions


# ── DeepSeek 辅助 ─────────────────────────────────────────────────────────────

def llm_judge(system: str, user: str) -> str:
    client = get_client()
    resp = client.chat.completions.create(
        model=LLM_MODEL,
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
        temperature=0,
        max_tokens=512,
    )
    return resp.choices[0].message.content.strip()


# ── 原生版 RAG 调用 ──────────────────────────────────────────────────────────

def run_native_rag(questions: list[dict]) -> list[dict]:
    sys.path.insert(0, str(BASE_DIR / "src"))
    from rag_pipeline_reviews import RAGPipeline

    logger.info("初始化原生评论 RAG Pipeline...")
    pipeline = RAGPipeline(use_bm25=True, use_rerank=False)

    results = []
    for q in questions:
        logger.info(f"[{q['id']:02d}] {q['question'][:40]}...")
        try:
            result = pipeline.query(q["question"], verbose=False)
            results.append({
                "question":     q["question"],
                "answer":       result["answer"],
                "contexts":     [r["content"] for r in result["retrieved"]],
                "ground_truth": q["ground_truth"],
                "question_id":  q["id"],
                "question_type":q["type"],
            })
        except Exception as e:
            logger.error(f"  题目 {q['id']} 失败: {e}")
            results.append({
                "question":     q["question"],
                "answer":       f"ERROR: {e}",
                "contexts":     [],
                "ground_truth": q["ground_truth"],
                "question_id":  q["id"],
                "question_type":q["type"],
            })
    return results


# ── LangChain 版 RAG 调用 ────────────────────────────────────────────────────

def run_langchain_rag(questions: list[dict]) -> list[dict]:
    sys.path.insert(0, str(BASE_DIR / "src_langchain"))

    import importlib.util
    spec   = importlib.util.spec_from_file_location(
        "rag_chain_lc_reviews",
        BASE_DIR / "src_langchain" / "rag_chain_lc_reviews.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    logger.info("初始化 LangChain 评论 RAG 链...")
    embeddings  = module.get_embeddings()
    vectorstore = module.get_vectorstore(embeddings)
    chain, retriever = module.build_chain(vectorstore)

    results = []
    for q in questions:
        logger.info(f"[{q['id']:02d}] {q['question'][:40]}...")
        try:
            retrieved_docs = retriever.invoke(q["question"])
            contexts       = [doc.page_content for doc in retrieved_docs]
            answer         = chain.invoke(q["question"])
            results.append({
                "question":     q["question"],
                "answer":       answer,
                "contexts":     contexts,
                "ground_truth": q["ground_truth"],
                "question_id":  q["id"],
                "question_type":q["type"],
            })
        except Exception as e:
            logger.error(f"  题目 {q['id']} 失败: {e}")
            results.append({
                "question":     q["question"],
                "answer":       f"ERROR: {e}",
                "contexts":     [],
                "ground_truth": q["ground_truth"],
                "question_id":  q["id"],
                "question_type":q["type"],
            })
    return results


# ── 手动指标计算（无 RAGAS 依赖）─────────────────────────────────────────────

def calc_faithfulness(answer: str, contexts: list[str]) -> float:
    """答案是否忠实于上下文（0~1）"""
    if not answer or not contexts:
        return 0.0
    ctx_joined = "\n---\n".join(contexts[:3])
    prompt = (
        "你是一个评估助手。请判断以下回答是否忠实于给定的参考信息。\n\n"
        "打分标准：\n"
        "  - 1分：回答中的所有关键信息都在参考信息中有依据，没有捏造或矛盾\n"
        "  - 0分：回答中包含参考信息中不存在的数据、结论，或与参考信息矛盾\n\n"
        "只输出0或1，不要其他文字。\n\n"
        f"参考信息：\n{ctx_joined}\n\n"
        f"回答：\n{answer}\n\n"
        "输出（0或1）："
    )
    try:
        score = llm_judge("你是一个严格的评估助手。", prompt)
        return 1.0 if "1" in score.strip() else 0.0
    except Exception:
        return 0.0


def calc_answer_relevancy(question: str, answer: str) -> float:
    """答案与问题的相关性（0~1）"""
    if not answer:
        return 0.0
    prompt = (
        "你是一个评估助手。请判断以下回答是否与问题相关。\n\n"
        "打分标准：\n"
        "  - 1分：回答直接回应了问题，提供了相关信息\n"
        "  - 0分：回答与问题无关，答非所问\n\n"
        "只输出0或1，不要其他文字。\n\n"
        f"问题：\n{question}\n\n"
        f"回答：\n{answer}\n\n"
        "输出（0或1）："
    )
    try:
        score = llm_judge("你是一个严格的评估助手。", prompt)
        return 1.0 if "1" in score.strip() else 0.0
    except Exception:
        return 0.0


def calc_context_precision(question: str, contexts: list[str]) -> float:
    """上下文中包含多少必要信息（0~1）"""
    if not contexts:
        return 0.0
    ctx_joined = "\n---\n".join(contexts[:3])
    prompt = (
        "你是一个评估助手。请判断给定的参考信息是否包含回答以下问题所需的必要信息。\n\n"
        "打分标准：\n"
        "  - 1分：参考信息充分，足以准确回答问题\n"
        "  - 0分：参考信息不足或无关，无法回答问题\n\n"
        "只输出0或1，不要其他文字。\n\n"
        f"问题：\n{question}\n\n"
        f"参考信息：\n{ctx_joined}\n\n"
        "输出（0或1）："
    )
    try:
        score = llm_judge("你是一个严格的评估助手。", prompt)
        return 1.0 if "1" in score.strip() else 0.0
    except Exception:
        return 0.0


def calc_context_recall(ground_truth: str, contexts: list[str]) -> float:
    """标准答案中的信息是否在上下文中被覆盖（0~1）"""
    if not ground_truth or not contexts:
        return 0.0
    ctx_joined = "\n---\n".join(contexts[:3])
    prompt = (
        "你是一个评估助手。请判断以下标准答案中的关键信息是否被参考信息所覆盖。\n\n"
        "打分标准：\n"
        "  - 1分：标准答案中的全部关键信息都可以在参考信息中找到\n"
        "  - 0分：标准答案中的部分或全部关键信息在参考信息中找不到\n\n"
        "只输出0或1，不要其他文字。\n\n"
        f"标准答案：\n{ground_truth}\n\n"
        f"参考信息：\n{ctx_joined}\n\n"
        "输出（0或1）："
    )
    try:
        score = llm_judge("你是一个严格的评估助手。", prompt)
        return 1.0 if "1" in score.strip() else 0.0
    except Exception:
        return 0.0


# ── 批量计算 ──────────────────────────────────────────────────────────────────

def compute_all_metrics(results: list[dict]) -> dict:
    faithfulness_list     = []
    relevancy_list        = []
    precision_list        = []
    recall_list           = []

    # should_refuse 类型的题目跳过指标计算（但检查是否正确拒绝）
    for r in results:
        if r.get("question_type") == "should_refuse":
            continue
        if r["answer"].startswith("ERROR"):
            continue

        logger.info(f"  评估题 {r['question_id']}: {r['question'][:20]}...")
        faithful  = calc_faithfulness(r["answer"], r["contexts"])
        relevance = calc_answer_relevancy(r["question"], r["answer"])
        precision = calc_context_precision(r["question"], r["contexts"])
        recall    = calc_context_recall(r["ground_truth"], r["contexts"])
        r["_faithfulness"]      = faithful
        r["_answer_relevancy"]  = relevance
        r["_context_precision"] = precision
        r["_context_recall"]    = recall

        faithfulness_list.append(faithful)
        relevancy_list.append(relevance)
        precision_list.append(precision)
        recall_list.append(recall)

    scores = {
        "faithfulness":       float(np.mean(faithfulness_list)) if faithfulness_list else 0.0,
        "answer_relevancy":   float(np.mean(relevancy_list))    if relevancy_list    else 0.0,
        "context_precision":  float(np.mean(precision_list))   if precision_list    else 0.0,
        "context_recall":     float(np.mean(recall_list))      if recall_list       else 0.0,
    }

    logger.info(f"\n{'='*50}")
    for k, v in scores.items():
        logger.info(f"  {k}: {v:.4f}")

    return scores


# ── 按题型分析 ────────────────────────────────────────────────────────────────

def analyze_by_type(results: list[dict]):
    from collections import defaultdict

    type_stats = defaultdict(list)
    for r in results:
        qtype  = r.get("question_type", "unknown")
        answer = r.get("answer", "")
        refused = any(kw in answer for kw in ["无法回答", "无法提供", "不在", "不包含", "超出", "无法预测", "无法判断"])
        type_stats[qtype].append({"refused": refused, "answer_len": len(answer)})

    print("\n── 按题型统计 ──")
    print(f"{'题型':<25} {'题数':>4} {'拒绝率':>8} {'平均回答长度':>12}")
    print("-" * 55)
    for qtype, stats in sorted(type_stats.items()):
        refuse_rate = sum(1 for s in stats if s["refused"]) / len(stats)
        avg_len     = sum(s["answer_len"] for s in stats) / len(stats)
        print(f"{qtype:<25} {len(stats):>4}  {refuse_rate:>7.0%}  {avg_len:>10.0f}字")


# ── 保存结果 ──────────────────────────────────────────────────────────────────

def save_results(raw_results: list[dict], scores: dict, pipeline_name: str):
    import pandas as pd
    from datetime import datetime

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path  = RESULT_DIR / f"reviews_{pipeline_name}_{timestamp}.json"

    output = {
        "pipeline":    pipeline_name,
        "timestamp":   timestamp,
        "scores":      scores,
        "raw_results": raw_results,
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    logger.info(f"详细结果已保存 → {out_path}")

    df = pd.DataFrame([{
        "id":       r["question_id"],
        "type":     r["question_type"],
        "question": r["question"][:30] + "...",
        "faithfulness":      r.get("_faithfulness", ""),
        "answer_relevancy":  r.get("_answer_relevancy", ""),
        "context_precision": r.get("_context_precision", ""),
        "context_recall":    r.get("_context_recall", ""),
        "answer_len": len(r["answer"]),
        "contexts":  len(r["contexts"]),
    } for r in raw_results])
    csv_path = RESULT_DIR / f"reviews_{pipeline_name}_{timestamp}.csv"
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")
    logger.info(f"CSV 摘要已保存 → {csv_path}")


# ── 两版对比输出 ──────────────────────────────────────────────────────────────

def print_comparison(native_scores: dict, lc_scores: dict):
    metrics = ["faithfulness", "answer_relevancy", "context_precision", "context_recall"]
    labels  = {
        "faithfulness":       "忠实度",
        "answer_relevancy":   "答案相关性",
        "context_precision":  "上下文精确率",
        "context_recall":     "上下文召回率",
    }

    print(f"\n{'='*65}")
    print(f"{'指标':<20} {'原生版（BM25+Vec）':>20} {'LangChain版（纯Vec）':>20}")
    print(f"{'='*65}")
    for m in metrics:
        n_val = native_scores.get(m, 0)
        l_val = lc_scores.get(m, 0)
        diff  = n_val - l_val
        arrow = "↑" if diff > 0.01 else ("↓" if diff < -0.01 else "≈")
        print(f"{labels[m]:<20} {n_val:>20.4f} {l_val:>20.4f}  {arrow}")
    print(f"{'='*65}")


# ── 入口 ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="热成像评论 RAGAS 评估（手动版）")
    parser.add_argument("--pipeline",     choices=["native", "langchain", "both"], default="native")
    parser.add_argument("--question-ids", type=str, default=None, help="指定题号，逗号分隔")
    parser.add_argument("--dry-run",      action="store_true", help="只打印答案，跳过打分")
    args = parser.parse_args()

    q_ids = [int(x) for x in args.question_ids.split(",")] if args.question_ids else None
    questions = load_questions(q_ids)
    logger.info(f"加载 {len(questions)} 道测试题")

    native_results = lc_results = None
    native_scores  = lc_scores  = None

    if args.pipeline in ("native", "both"):
        native_results = run_native_rag(questions)
        analyze_by_type(native_results)
        if not args.dry_run:
            native_scores = compute_all_metrics(native_results)
            save_results(native_results, native_scores, "native")

    if args.pipeline in ("langchain", "both"):
        lc_results = run_langchain_rag(questions)
        analyze_by_type(lc_results)
        if not args.dry_run:
            lc_scores = compute_all_metrics(lc_results)
            save_results(lc_results, lc_scores, "langchain")

    if args.pipeline == "both" and native_scores and lc_scores:
        print_comparison(native_scores, lc_scores)


if __name__ == "__main__":
    main()
