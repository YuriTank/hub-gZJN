"""
评论向量索引构建脚本（LangChain 版）

与 langchain 版年报建索引（build_index_lc.py）的区别：
  年报版：PyMuPDFLoader 加载 PDF → RecursiveCharacterTextSplitter 分块
  评论版：加载 parse_xlsx.py 输出的 JSON → 每条评论作为一个 Document

数据源：data/parsed/竞品Review分析_final.json（9222 条评论）

向量库保存在：vectorstore/faiss_lc_reviews/

依赖：
  pip install langchain langchain-community langchain-huggingface faiss-cpu sentence-transformers
"""

import json
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

BASE_DIR        = Path(__file__).parent.parent
PARSED_DIR      = BASE_DIR / "data" / "parsed"
VECTORSTORE_DIR = BASE_DIR / "vectorstore" / "faiss_lc_reviews"
MODELS_DIR      = BASE_DIR / "models"
BGE_MODEL_PATH  = MODELS_DIR / "bge-small-zh-v1.5"


def load_documents():
    """
    从 parse_xlsx.py 输出的 JSON 加载评论，
    每条评论转为一个 LangChain Document。
    """
    from langchain_core.documents import Document

    parsed_files = list(PARSED_DIR.glob("*Review*.json")) + list(PARSED_DIR.glob("*review*.json"))
    if not parsed_files:
        parsed_files = list(PARSED_DIR.glob("*.json"))

    all_docs = []
    for json_path in sorted(parsed_files):
        logger.info(f"加载: {json_path.name}")
        with open(json_path, encoding="utf-8") as f:
            data = json.load(f)

        blocks = data.get("blocks", [])
        for block in blocks:
            content = block.get("content", "").strip()
            if not content:
                continue

            # 评论专有元信息（供检索过滤和引用）
            metadata = {
                "source_file":   json_path.name,
                "section":       " > ".join(block.get("section_path", [])),
                "brand":         block.get("brand", ""),
                "model":         block.get("model", ""),
                "product_type":  block.get("product_type", ""),
                "form_factor":   block.get("form_factor", ""),
                "site":          block.get("site", ""),
                "country":       block.get("country", ""),
                "rating":        block.get("rating", 0),
                "verified":      block.get("verified", False),
                "date":          block.get("date", ""),
                "asin":          block.get("asin", ""),
                "helpful_votes": block.get("helpful_votes", 0),
                "vine_voice":    block.get("vine_voice", False),
            }
            doc = Document(page_content=content, metadata=metadata)
            all_docs.append(doc)

        logger.info(f"  → {len(blocks)} 条评论")

    logger.info(f"共加载 {len(all_docs)} 条评论")
    return all_docs


def get_embeddings():
    from langchain_huggingface import HuggingFaceEmbeddings

    model_path = str(BGE_MODEL_PATH) if BGE_MODEL_PATH.exists() else "BAAI/bge-small-zh-v1.5"
    if not BGE_MODEL_PATH.exists():
        logger.warning(f"本地模型不存在: {BGE_MODEL_PATH}，将从 HuggingFace 下载")

    embeddings = HuggingFaceEmbeddings(
        model_name=model_path,
        cache_folder=str(MODELS_DIR),
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )
    logger.info(f"Embedding 模型加载完成: {model_path}")
    return embeddings


def build_vectorstore(docs, embeddings):
    from langchain_community.vectorstores import FAISS

    VECTORSTORE_DIR.mkdir(parents=True, exist_ok=True)

    logger.info(f"构建向量库（{len(docs)} 条评论）...")
    vectorstore = FAISS.from_documents(docs, embeddings)

    vectorstore.save_local(str(VECTORSTORE_DIR))
    faiss_file = VECTORSTORE_DIR / "index.faiss"
    logger.info(f"向量库已保存 → {VECTORSTORE_DIR}")
    logger.info(f"  index.faiss: {faiss_file.stat().st_size // 1024} KB" if faiss_file.exists() else "")
    return vectorstore


def main():
    docs       = load_documents()
    embeddings = get_embeddings()
    build_vectorstore(docs, embeddings)

    print(f"\nLangChain 评论向量库构建完成！")
    print(f"  路径: {VECTORSTORE_DIR}")
    print(f"  共 {len(docs)} 条评论")
    print(f"  下一步: python src_langchain/rag_chain_lc_reviews.py")


if __name__ == "__main__":
    main()
