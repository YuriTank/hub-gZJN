"""
热成像评论 RAG 问答链（LangChain LCEL 版）

与原生版（rag_pipeline_reviews.py）的对比：
  LangChain 版使用 FAISS 单路检索 + LCEL 链式调用，代码更简洁。
  原生版使用 FAISS + BM25 混合检索 + RRF 融合 + CrossEncoder 精排，准确度更高。

使用方式：
  python rag_chain_lc_reviews.py                              # 交互式
  python rag_chain_lc_reviews.py --query "FLIR 用户群体"
  python rag_chain_lc_reviews.py --query "..." --with-sources  # 附带来源
  python rag_chain_lc_reviews.py --query "..." --brand FLIR    # 品牌过滤

依赖：
  pip install langchain langchain-openai langchain-community langchain-huggingface faiss-cpu
  export DEEPSEEK_API_KEY="sk-xxx"
"""

import os
import argparse
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

BASE_DIR        = Path(__file__).parent.parent
VECTORSTORE_DIR = BASE_DIR / "vectorstore" / "faiss_lc_reviews"
MODELS_DIR      = BASE_DIR / "models"
BGE_MODEL_PATH  = MODELS_DIR / "bge-small-zh-v1.5"

LLM_BASE_URL    = "https://api.deepseek.com"
LLM_MODEL       = "deepseek-v4-pro"

SYSTEM_PROMPT = """你是一个专业的亚马逊热成像产品评论分析助手，专门回答关于热成像产品用户反馈的问题。

回答规则：
1. 只根据【参考资料】中的评论内容回答，不得编造数据
2. 若参考资料不足以支撑回答，直接说"根据提供的评论数据无法回答此问题"
3. 引用时标注品牌、型号和评分，如：用户反馈画质清晰（FLIR One Pro, ★5.0）
4. 回答要结构化：先给结论，再列依据（分点说明）
5. 涉及产品信息时标注品牌、型号、产品类型"""


# ── 组件初始化 ────────────────────────────────────────────────────────────────

def get_llm():
    from langchain_openai import ChatOpenAI

    api_key = os.getenv("DEEPSEEK_API_KEY")
    if not api_key:
        raise EnvironmentError("请设置环境变量 DEEPSEEK_API_KEY")

    return ChatOpenAI(
        model=LLM_MODEL,
        openai_api_key=api_key,
        openai_api_base=LLM_BASE_URL,
        temperature=0.1,
    )


def get_embeddings():
    from langchain_huggingface import HuggingFaceEmbeddings

    model_path = str(BGE_MODEL_PATH) if BGE_MODEL_PATH.exists() else "BAAI/bge-small-zh-v1.5"
    return HuggingFaceEmbeddings(
        model_name=model_path,
        cache_folder=str(MODELS_DIR),
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def get_vectorstore(embeddings):
    from langchain_community.vectorstores import FAISS

    if not VECTORSTORE_DIR.exists():
        raise FileNotFoundError(
            f"向量库不存在: {VECTORSTORE_DIR}\n"
            "请先运行: python src_langchain/build_index_lc_reviews.py"
        )
    return FAISS.load_local(
        str(VECTORSTORE_DIR),
        embeddings,
        allow_dangerous_deserialization=True,
    )


# ── LCEL 链构建 ───────────────────────────────────────────────────────────────

def build_chain(vectorstore, filter_meta: dict = None):
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.runnables import RunnablePassthrough
    from langchain_core.output_parsers import StrOutputParser

    llm = get_llm()

    search_kwargs = {"k": 5}
    if filter_meta:
        search_kwargs["filter"] = filter_meta

    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs=search_kwargs,
    )

    def format_docs(docs) -> str:
        parts = []
        for i, doc in enumerate(docs, 1):
            meta = doc.metadata
            brand   = meta.get("brand", "")
            model   = meta.get("model", "")
            ptype   = meta.get("product_type", "")
            rating  = meta.get("rating", "")
            country = meta.get("country", "")
            date    = meta.get("date", "")

            label_parts = [f"[{i}]"]
            if brand:  label_parts.append(brand)
            if model:  label_parts.append(model)
            if ptype:  label_parts.append(f"({ptype})")
            if rating: label_parts.append(f"★{rating}")
            if country: label_parts.append(country)
            if date:   label_parts.append(date)
            label = " ".join(label_parts)

            parts.append(f"{label}\n{doc.page_content}")
        return "\n\n---\n\n".join(parts)

    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        ("human", "【参考资料】\n{context}\n\n【问题】\n{question}\n\n请根据参考资料回答，在引用信息处标注来源品牌和评分。"),
    ])

    chain = (
        {
            "context":  retriever | format_docs,
            "question": RunnablePassthrough(),
        }
        | prompt
        | llm
        | StrOutputParser()
    )
    return chain, retriever


def build_chain_with_sources(vectorstore, filter_meta: dict = None):
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.runnables import RunnablePassthrough, RunnableParallel
    from langchain_core.output_parsers import StrOutputParser

    llm = get_llm()

    search_kwargs = {"k": 5}
    if filter_meta:
        search_kwargs["filter"] = filter_meta

    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs=search_kwargs,
    )

    def format_docs(docs) -> str:
        parts = []
        for i, doc in enumerate(docs, 1):
            meta = doc.metadata
            brand   = meta.get("brand", "")
            model   = meta.get("model", "")
            ptype   = meta.get("product_type", "")
            rating  = meta.get("rating", "")
            country = meta.get("country", "")
            date    = meta.get("date", "")

            label_parts = [f"[{i}]"]
            if brand:  label_parts.append(brand)
            if model:  label_parts.append(model)
            if ptype:  label_parts.append(f"({ptype})")
            if rating: label_parts.append(f"★{rating}")
            if country: label_parts.append(country)
            if date:   label_parts.append(date)
            label = " ".join(label_parts)

            parts.append(f"{label}\n{doc.page_content}")
        return "\n\n---\n\n".join(parts)

    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        ("human", "【参考资料】\n{context}\n\n【问题】\n{question}"),
    ])

    rag_chain_from_docs = (
        RunnablePassthrough.assign(context=lambda x: format_docs(x["context"]))
        | prompt | llm | StrOutputParser()
    )

    chain_with_sources = RunnableParallel(
        {
            "context":  retriever,
            "question": RunnablePassthrough(),
        }
    ).assign(answer=rag_chain_from_docs)

    return chain_with_sources


# ── 主流程 ────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="热成像评论 RAG 问答（LangChain LCEL 版）")
    parser.add_argument("--query",        type=str, default=None)
    parser.add_argument("--with-sources", action="store_true", help="输出结果时附带来源文档片段")
    parser.add_argument("--brand",        type=str, default=None, help="品牌过滤")
    parser.add_argument("--product-type", type=str, default=None, help="产品类型过滤")
    parser.add_argument("--form-factor",  type=str, default=None, help="形态过滤")
    parser.add_argument("--country",      type=str, default=None, help="国家过滤")
    parser.add_argument("--site",         type=str, default=None, help="站点过滤")
    args = parser.parse_args()

    filter_meta = {}
    if args.brand:        filter_meta["brand"]        = args.brand
    if args.product_type: filter_meta["product_type"] = args.product_type
    if args.form_factor:  filter_meta["form_factor"]  = args.form_factor
    if args.country:      filter_meta["country"]      = args.country
    if args.site:         filter_meta["site"]         = args.site
    if not filter_meta:
        filter_meta = None

    logger.info("加载 embedding 模型...")
    embeddings  = get_embeddings()
    logger.info("加载向量库...")
    vectorstore = get_vectorstore(embeddings)

    if args.with_sources:
        chain = build_chain_with_sources(vectorstore, filter_meta)
    else:
        chain, _ = build_chain(vectorstore, filter_meta)

    def run_query(question: str):
        print(f"\n{'='*60}")
        print(f"问题：{question}")
        if filter_meta:
            print(f"过滤：{filter_meta}")
        print(f"{'='*60}")

        if args.with_sources:
            result  = chain.invoke(question)
            answer  = result["answer"]
            sources = result["context"]
            print(f"\n{answer}")
            print("\n── 来源文档片段 ──")
            for i, doc in enumerate(sources, 1):
                meta = doc.metadata
                brand = meta.get("brand", "")
                model = meta.get("model", "")
                print(f"[{i}] {brand} {model} ★{meta.get('rating', '')} {meta.get('country', '')}")
                print(f"    {doc.page_content[:120]}...")
        else:
            answer = chain.invoke(question)
            print(f"\n{answer}")

    if args.query:
        run_query(args.query)
    else:
        print(f"热成像评论 RAG 问答系统（LangChain LCEL 版）")
        print(f"模型：{LLM_MODEL}  |  向量库：{VECTORSTORE_DIR}")
        print(f"共 9222 条评论 | 支持 --brand / --product-type / --form-factor 过滤")
        print("输入 'exit' 退出\n")
        while True:
            try:
                q = input("问题：").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if not q or q.lower() == "exit":
                break
            run_query(q)


if __name__ == "__main__":
    main()
