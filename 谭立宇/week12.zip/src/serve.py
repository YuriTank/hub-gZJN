"""
FastAPI HTTP 服务，提供流式 SSE 接口给 Web UI

接口：
  POST /query/manual     - 手写版 ReAct，流式返回每步（支持多轮对话）
  POST /query/fc         - Function Calling 版，流式返回每步（支持多轮对话）
  POST /session/create   - 创建新会话，返回 session_id
  POST /session/{sid}/clear - 清空会话历史
  GET  /session/{sid}/history - 获取会话历史轮次
  GET  /health           - 健康检查

使用方式：
  uvicorn serve:app --host 0.0.0.0 --port 8000
"""

import os
import sys
import json
import logging
import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
sys.path.insert(0, str(Path(__file__).parent))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ── 会话管理 ────────────────────────────────────────────────────────────────
from session import sessions, Turn


# ── 定时清理过期会话 ─────────────────────────────────────────────────────────
async def _periodic_cleanup():
    while True:
        await asyncio.sleep(600)  # 每10分钟清理一次
        sessions.cleanup()


# ── 预加载 FAISS + 启动清理任务 ─────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("预加载 FAISS 索引和 Embedding 模型...")
    from tools import _load_rag
    await asyncio.to_thread(_load_rag)
    logger.info("预加载完成，服务就绪")

    cleanup_task = asyncio.create_task(_periodic_cleanup())
    yield
    cleanup_task.cancel()


app = FastAPI(title="ReAct Financial Agent", lifespan=lifespan)


# ── 请求/响应模型 ─────────────────────────────────────────────────────────────
class QueryRequest(BaseModel):
    question: str
    max_steps: int = 10
    session_id: str | None = None
    context_window: int | None = None  # 最多带几轮历史，None=全部


# ── SSE 流式生成器 ────────────────────────────────────────────────────────────
def _sse(data: dict) -> str:
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"


async def _stream_react(question: str, max_steps: int, mode: str,
                         session_id: str | None = None,
                         context_window: int | None = None):
    """
    同步生成器（react_run）在独立线程中逐步执行，
    每产出一步通过 asyncio.Queue 传递给异步 SSE 生成器，
    实现真正的边思考边推送。

    支持多轮对话：通过 session_id 获取历史消息，本轮结束后保存结果。
    """
    if mode == "manual":
        from react_manual import run as react_run
    else:
        from react_function_calling import run as react_run

    # 从 session 获取历史消息
    existing_messages = None
    if session_id:
        existing_messages = sessions.get_messages(session_id, window=context_window)

    queue: asyncio.Queue = asyncio.Queue()
    _SENTINEL = object()

    def _worker():
        try:
            for step_data in react_run(question, max_steps=max_steps,
                                       existing_messages=existing_messages):
                queue.put_nowait(step_data)
        finally:
            queue.put_nowait(_SENTINEL)

    yield _sse({"type": "start", "question": question, "mode": mode})

    loop = asyncio.get_event_loop()
    loop.run_in_executor(None, _worker)

    last_messages = None
    final_answer = ""
    all_steps = []

    while True:
        step_data = await queue.get()
        if step_data is _SENTINEL:
            break

        # 收集信息用于保存到 session
        if "messages" in step_data:
            last_messages = step_data["messages"]
        if step_data.get("type") == "final":
            final_answer = step_data.get("answer", "")
        if step_data.get("type") == "action":
            all_steps.append(step_data)

        # SSE 中不发送 messages（太大），只发送展示用字段
        sse_data = {k: v for k, v in step_data.items() if k != "messages"}
        yield _sse(sse_data)

    # 保存本轮到 session
    if session_id and last_messages is not None:
        sessions.append_turn(session_id, Turn(
            question=question,
            answer=final_answer,
            steps=all_steps,
            messages=last_messages,
        ))

    yield _sse({"type": "done"})


# ── 路由 ──────────────────────────────────────────────────────────────────────

@app.post("/session/create")
async def create_session():
    """创建新会话"""
    sid = sessions.create()
    return {"session_id": sid}


@app.post("/session/{sid}/clear")
async def clear_session(sid: str):
    """清空会话历史"""
    ok = sessions.clear(sid)
    return {"ok": ok}


@app.get("/session/{sid}/history")
async def get_history(sid: str):
    """获取会话历史轮次（用于前端恢复）"""
    s = sessions.get(sid)
    if not s:
        return {"turns": []}
    return {
        "turns": [
            {"question": t.question, "answer": t.answer}
            for t in s.turns
        ]
    }


@app.post("/query/manual")
async def query_manual(req: QueryRequest):
    return StreamingResponse(
        _stream_react(req.question, req.max_steps, "manual",
                       session_id=req.session_id,
                       context_window=req.context_window),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/query/fc")
async def query_fc(req: QueryRequest):
    return StreamingResponse(
        _stream_react(req.question, req.max_steps, "fc",
                       session_id=req.session_id,
                       context_window=req.context_window),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "model": os.getenv("AGENT_MODEL", "qwen-max"),
        "sessions": sessions.stats(),
    }


# ── 托管 index.html ──────────────────────────────────────────────────────────
HTML_PATH = Path(__file__).parent.parent / "index.html"

@app.get("/")
async def root():
    if HTML_PATH.exists():
        return HTMLResponse(HTML_PATH.read_text(encoding="utf-8"))
    return HTMLResponse("<h2>index.html not found</h2>")
