"""
会话管理模块：支持多轮对话的上下文持久化

设计要点：
  - 内存存储，TTL 自动过期清理
  - 每轮存储完整 messages 列表，用于恢复 LLM 上下文
  - 线程安全通过 GIL 保证（单进程场景足够）

使用方式：
  from session import sessions
  sid = sessions.create()
  sessions.append_turn(sid, Turn(...))
  history = sessions.get_messages(sid, window=3)
"""

import uuid
import time
import copy
import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class Turn:
    """一轮对话的完整记录"""
    question: str
    answer: str
    steps: list[dict] = field(default_factory=list)   # 每步的 step_result（不含 messages）
    messages: list[dict] = field(default_factory=list) # 完整 OpenAI messages（用于下轮上下文）
    timestamp: float = field(default_factory=time.time)


@dataclass
class Session:
    """一个会话"""
    sid: str
    turns: list[Turn] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    last_accessed: float = field(default_factory=time.time)


class SessionManager:
    """
    内存会话管理器

    Args:
        ttl: 会话过期时间（秒），默认1小时
        max_turns: 每个会话最多保留轮数，超出后丢弃最早的
    """

    def __init__(self, ttl: int = 3600, max_turns: int = 20):
        self._sessions: dict[str, Session] = {}
        self._ttl = ttl
        self._max_turns = max_turns

    def create(self) -> str:
        """创建新会话，返回 session_id"""
        sid = uuid.uuid4().hex[:12]
        self._sessions[sid] = Session(sid=sid)
        logger.info(f"Session created: {sid}")
        return sid

    def get(self, sid: str) -> Session | None:
        """获取会话，同时刷新 last_accessed"""
        s = self._sessions.get(sid)
        if s is not None:
            s.last_accessed = time.time()
        return s

    def append_turn(self, sid: str, turn: Turn) -> bool:
        """追加一轮对话记录，超出 max_turns 时丢弃最早的"""
        s = self._sessions.get(sid)
        if s is None:
            logger.warning(f"append_turn: session {sid} not found")
            return False
        s.turns.append(turn)
        if len(s.turns) > self._max_turns:
            s.turns = s.turns[-self._max_turns:]
        s.last_accessed = time.time()
        return True

    def get_messages(self, sid: str, window: int | None = None) -> list[dict] | None:
        """
        获取指定会话的上下文 messages，用于下一轮对话。

        返回最近 window 轮的完整 messages 拼接（不含 system prompt，
        system prompt 由 run() 函数自行添加）。

        Args:
            sid: 会话ID
            window: 最多带几轮历史，None 表示全部

        Returns:
            messages 列表，或 None（会话不存在或无历史）
        """
        s = self._sessions.get(sid)
        if s is None or not s.turns:
            return None

        turns = s.turns
        if window is not None and window > 0:
            turns = turns[-window:]

        # 拼接所有历史轮的 messages（跳过 system prompt，因为它会被 run() 重新添加）
        messages = []
        for turn in turns:
            if turn.messages:
                # 从 turn.messages 中提取非 system 消息
                for m in turn.messages:
                    if isinstance(m, dict) and m.get("role") != "system":
                        messages.append(m)
                    elif hasattr(m, "role") and m.role != "system":
                        # OpenAI SDK 对象
                        messages.append(m)

        return messages if messages else None

    def clear(self, sid: str) -> bool:
        """清空会话的历史轮次"""
        s = self._sessions.get(sid)
        if s is None:
            return False
        s.turns.clear()
        s.last_accessed = time.time()
        return True

    def delete(self, sid: str) -> bool:
        """删除整个会话"""
        if sid in self._sessions:
            del self._sessions[sid]
            return True
        return False

    def cleanup(self) -> int:
        """清理过期会话，返回清理数量"""
        now = time.time()
        expired = [k for k, v in self._sessions.items()
                   if now - v.last_accessed > self._ttl]
        for k in expired:
            del self._sessions[k]
        if expired:
            logger.info(f"Cleaned up {len(expired)} expired sessions")
        return len(expired)

    def stats(self) -> dict:
        """返回当前会话统计"""
        return {
            "total_sessions": len(self._sessions),
            "total_turns": sum(len(s.turns) for s in self._sessions.values()),
        }


# 全局单例
sessions = SessionManager()
