"""
统一入口：切换手写版 / Function Calling 版 ReAct Agent

使用方式：
  单轮模式：
    python agent.py
    python agent.py --mode manual   --question "茅台2023年毛利率是多少？"
    python agent.py --mode fc       --question "五粮液近一年股价涨跌幅？"
    python agent.py --mode manual   --question "..." --max_steps 8

  交互式多轮模式（不传 --question 自动进入）：
    python agent.py --mode manual
    python agent.py --mode fc

环境变量：
  DASHSCOPE_API_KEY  必填
  AGENT_MODEL        默认 qwen-max，可换 deepseek-v3 等
"""

import os
import argparse

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

DEFAULT_QUESTION = "贵州茅台和五粮液2023年的毛利率哪家更高？差多少个百分点？"


def interactive_loop(mode: str, max_steps: int):
    """交互式多轮对话循环"""
    if mode == "manual":
        from react_manual import run_and_print
    else:
        from react_function_calling import run_and_print

    mode_label = "手写Prompt解析" if mode == "manual" else "Function Calling"

    print(f"\n{'='*60}")
    print(f"ReAct Financial Agent — 交互式多轮对话")
    print(f"模型: {os.getenv('AGENT_MODEL', 'qwen-max')}  实现: {mode_label}")
    print(f"输入 q / quit / exit 退出，输入 new / clear 开始新对话")
    print(f"{'='*60}")

    messages = None  # 让 run() 自己初始化 system prompt
    turn_count = 0

    while True:
        try:
            question = input(f"\033[36m\n你 (第{turn_count + 1}轮): \033[0m").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\n再见！")
            break

        if not question:
            continue
        if question in ("q", "quit", "exit"):
            print("\n再见！")
            break
        if question in ("new", "clear", "重置"):
            messages = None
            turn_count = 0
            print("\033[33m--- 已重置对话历史 ---\033[0m")
            continue

        messages = run_and_print(question, max_steps, existing_messages=messages)
        turn_count += 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ReAct Financial Agent")
    parser.add_argument(
        "--mode", choices=["manual", "fc"], default="manual",
        help="manual=手写Prompt解析版  fc=Function Calling版",
    )
    parser.add_argument("--question", default=None,
                        help="不指定则进入交互式多轮模式")
    parser.add_argument("--max_steps", type=int, default=10)
    args = parser.parse_args()

    if args.question:
        # 单轮模式
        if args.mode == "manual":
            from react_manual import run_and_print
        else:
            from react_function_calling import run_and_print
        run_and_print(args.question, args.max_steps)
    else:
        # 交互式多轮模式
        interactive_loop(args.mode, args.max_steps)
