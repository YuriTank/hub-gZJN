"""
扩展实验对比：新增题型融合训练（基座 vs fusion-checkpoint）

生成：
  outputs/figures/ext_fusion_curves.png   # 融合训练曲线
  控制台：14 题型前后对比表 + 新题型样例对照
"""
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).parent.parent
OUT = ROOT / "outputs"

LEVELS = [
    "L1_add_1digit", "L2_addsub_2digit", "L3_addsub_3digit",
    "L4_mul_1digit", "L5_mul_2x1digit", "L6_mul_2x2digit",
    "L7_div_1div1", "L8_div_2div1",
    "L9_mixed_addmul", "L10_paren_basic",
    "L11_eq_add", "L12_eq_mul",
    "L13_mixed_pemdas", "L14_paren_nested",
]
# 融合训练集内题型
TRAINED_LEVELS = {
    "L2_addsub_2digit", "L3_addsub_3digit", "L5_mul_2x1digit",
    "L7_div_1div1", "L8_div_2div1", "L11_eq_add", "L12_eq_mul",
}


def fmt_table(reports, levels=LEVELS):
    base = reports[0][1]
    header = f"{'难度':<20}{'训练集':^6}"
    for name, _ in reports:
        header += f"{'格式/正确/pass@8':^20}{'':<2}"
    rows = []
    for lv in levels:
        in_train = "√" if lv in TRAINED_LEVELS else "—"
        row = f"{lv:<20}{in_train:^6}"
        for name, rep in reports:
            r = rep[lv]
            cell = f"{r['greedy_format_rate']:.2f}/{r['greedy_loose_acc']:.2f}/{r['loose_pass@8']:.2f}"
            row += f"{cell:^20}{'':<2}"
        rows.append(row)
    return header + "\n" + "\n".join(rows)


def fmt_examples(base, post):
    lines = []
    new = ["L7_div_1div1", "L8_div_2div1", "L11_eq_add", "L12_eq_mul"]
    for lv in new:
        lines.append(f"\n--- {lv} ---")
        for eb, ep in zip(base[lv]["examples"], post[lv]["examples"]):
            lines.append(f"  {eb['expr']} = {eb['answer']}")
            lines.append(f"    前: {eb['greedy_output']!r}")
            lines.append(f"    后: {ep['greedy_output']!r}")
    return "\n".join(lines)


def plot_curves(log_entry, fig_path):
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    logs = [e for e in log_entry if "reward" in e]
    steps = [e["step"] for e in logs]
    axes[0].plot(steps, [e["rewards/reward_correct/mean"] for e in logs], label="fusion correct")
    axes[0].plot(steps, [e["rewards/reward_format/mean"] for e in logs], "--", label="fusion format")
    axes[1].plot(steps, [e["frac_reward_zero_std"] for e in logs], label="fusion")
    axes[2].plot(steps, [e["entropy"] for e in logs], label="fusion")
    for ax, t in zip(axes, ["Reward components", "frac_reward_zero_std", "Policy entropy"]):
        ax.set_title(t); ax.set_xlabel("step"); ax.legend(); ax.grid(alpha=0.3)
    fig.tight_layout()
    fig_path.parent.mkdir(exist_ok=True)
    fig.savefig(fig_path, dpi=150)
    print(f"融合训练曲线已保存：{fig_path}")


def main():
    with open(OUT / "baseline_probe_full.json", encoding="utf-8") as f:
        base = json.load(f)
    with open(OUT / "post_train_probe_fusion.json", encoding="utf-8") as f:
        post = json.load(f)
    with open(OUT / "train_log_fusion.json", encoding="utf-8") as f:
        log = json.load(f)

    print("=" * 100)
    print("扩展实验：新增题型融合训练前后对比（同一评估集 seed=42；格式率/greedy正确率/loose_pass@8）")
    print("=" * 100)
    print(fmt_table([("基线", base), ("融合", post)]))

    print("\n" + "=" * 100)
    print("新题型 greedy 输出对照（选入训练集的甜区题型）")
    print(fmt_examples(base, post))

    plot_curves(log, OUT / "figures" / "ext_fusion_curves.png")


if __name__ == "__main__":
    main()
